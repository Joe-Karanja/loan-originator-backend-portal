import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cb-base-rate',
  templateUrl: './cb-base-rate.component.html',
  styleUrls: ['./cb-base-rate.component.scss'],
})
export class CbBaseRateComponent implements OnInit {

  ngOnInit(): void {
  }

}
