import {ListProfilesComponent} from './rbac/profiles/list-profiles/list-profiles.component';
// tslint:disable-next-line:max-line-length
import {ModuleWithProviders} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {RolesListComponent} from './rbac/roles/roles-list/roles-list.component';
import {ListInsuranceProductsComponent} from './manage-insurance-products/list-insurance-products/list-insurance-products.component';
import {ViewInsuranceProductComponent} from './manage-insurance-products/view-insurance-product/view-insurance-product.component';
import {ListGaragesComponent} from './manage-garages/list-garages/list-garages.component';
import {ListInvestmentProductsComponent} from './manage-investment-products/list-investment-products/list-investment-products.component';
// tslint:disable-next-line:max-line-length
import {ViewInvestmentProductCategoriesComponent} from './manage-investment-products/view-investment-product-categories/view-investment-product-categories.component';
import {ListLoanProductsComponent} from './manage-loan-products/list-loan-products/list-loan-products.component';
import {ListRiskGroupComponent} from './manage-scoring-criteria/risk-group/list-risk-group/list-risk-group.component';
// tslint:disable-next-line:max-line-length
import {ListQualificationCriteriaComponent} from './manage-qualification-criteria/qualification-criteria/list-qualification-criteria/list-qualification-criteria.component';
import {ListLoanScoringGroupComponent} from './manage-scoring-criteria/scoring-group/list-loan-scoring-group/list-loan-scoring-group.component';
import {ListScoringParameterComponent} from './manage-scoring-criteria/score-parameter/list-scoring-parameter/list-scoring-parameter.component';
import {ListScoringParamItemComponent} from './manage-scoring-criteria/score-parameter-item/list-scoring-param-item/list-scoring-param-item.component';
import {ListQualificationParamsComponent} from './manage-qualification-criteria/qualification-params/list-qualification-params/list-qualification-params.component';
import {CbBaseRateComponent} from './manage-cb-base-rate/cb-base-rate/cb-base-rate.component';
import {ListScoringMatrixComponent} from './manage-scoring-criteria/scoring-matrix/list-scoring-matrices/list-scoring-matrix.component';
import {ListIndividualLoanScoringMatrixComponent} from './manage-scoring-criteria/scoring-matrix/list-individual-loan-scoring-matrices/list-individual-loan-scoring-matrix.component';
import {ListIndividualScoringParamItemComponent} from './manage-scoring-criteria/scoring-matrix/list-individual-loan-scoring-matrices/individual-score-parameter-item/list-individual-scoring-param-item/list-individual-scoring-param-item.component';
import {ListMandatoryChecksComponent} from './manage-qualification-criteria/mandatory-checks/list-mandatory-checks/list-mandatory-checks.component';
import {ListRevenueShareEntitiesComponent} from './manage-revenue-share/list-revenue-share-entity/list-revenue-share-entities.component';

const routes: Routes = [
    {
        path: 'loan-products',
        component: ListLoanProductsComponent,
        data: {
            breadcrumb: 'Loan Products',
            title: 'All Loan Products'
        }
    },
    {
        path: 'products',
        component: ListInsuranceProductsComponent,
        data: {
            breadcrumb: 'Insurance Products',
            title: 'Insurance Products'
        }
    },
    {
        path: 'investment-products',
        children: [

            {
                path: '',
                component: ListInvestmentProductsComponent,
                data: {
                    breadcrumb: 'Investment Products',
                    title: 'Investment Products'
                }
            },
            {
                path: ':id',
                component: ViewInvestmentProductCategoriesComponent,
                data: {breadcrumb: 'View'}
            },
        ]
    },
    {
        path: 'garages',
        component: ListGaragesComponent,
        data: {
            breadcrumb: 'Garages',
            title: 'List Garages'
        }
    },

    {
        path: 'rbac/roles',
        component: RolesListComponent,
        data: {
            breadcrumb: 'Roles',
            title: 'Roles'
        }
    },
    {
        path: 'rbac/profiles',
        component: ListProfilesComponent,
        data: {
            breadcrumb: 'Profiles',
            title: 'Profiles'
        }
    },

    // add new endpoints for scoring params and qualification criteria
    {
        path: 'scoring-matrices',
        children: [
            {
                path: '',
                component: ListScoringMatrixComponent,
                data: { breadcrumb: 'Scoring Matrices', title: 'Scoring Matrices' }
            },
            {
                path: 'individual-loan',
                component: ListIndividualLoanScoringMatrixComponent,
                data: { breadcrumb: 'Individual Loans Matrix', title: 'Individual Loans Matrix' }
            },
            {
                path: 'risk-groups',
                component: ListRiskGroupComponent,
                data: { breadcrumb: 'Scoring Risks', title: 'Scoring Risks' }
            },
            {
                path: 'risk-groups/scoring-groups',
                component: ListLoanScoringGroupComponent,
                data: {breadcrumb: 'List'}
            },
            {
                path: 'risk-groups/scoring-groups/scoring-params',
                component: ListScoringParameterComponent,
                data: {breadcrumb: 'List'}
            },
            {
                path: 'risk-groups/scoring-groups/scoring-params/scoring-params-items',
                component: ListScoringParamItemComponent,
                data: {breadcrumb: 'List'}
            },
            {
                path: 'risk-groups/scoring-groups/scoring-params/individual-scoring-params-items',
                component: ListIndividualScoringParamItemComponent,
                data: {breadcrumb: 'List'}
            },
        ]
    },



    {
        path: 'qualification-criteria',
        component: ListQualificationCriteriaComponent,
        data: {
            breadcrumb: 'Qualification Criteria',
            title: 'Qualification Criteria'
        }
    },

    {
        path: 'individual/qualification-criteria',
        component: ListQualificationParamsComponent,
        data: {
            breadcrumb: 'Qualification Criteria',
            title: 'Qualification Criteria'
        }
    },

    {
        path: 'individual/mandatory-checks',
        component: ListMandatoryChecksComponent,
        data: {
            breadcrumb: 'Mandatory Checks',
            title: 'Mandatory Checks'
        }
    },

    {
        path: 'cb-base-rate',
        component: CbBaseRateComponent,
        data: {
            breadcrumb: 'CB Base Rate',
            title: 'CB Base Rate'
        }
    },

    // Endpoint for revenue share
    {
        path: 'revenue-share',
        component: ListRevenueShareEntitiesComponent,
        data: {
            breadcrumb: 'Revenue Share',
            title: 'Revenue Share'
        }
    },

    {
        path: ':id',
        component: ViewInsuranceProductComponent,
        data: {
            breadcrumb: 'Insurance Product',
            title: ':id'
        }
    },



];

export const ConfigsRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);
