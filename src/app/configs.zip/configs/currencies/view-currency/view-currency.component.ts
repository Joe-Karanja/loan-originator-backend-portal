import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-currency',
  templateUrl: './view-currency.component.html',
  styleUrls: ['./view-currency.component.scss']
})
export class ViewCurrencyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
