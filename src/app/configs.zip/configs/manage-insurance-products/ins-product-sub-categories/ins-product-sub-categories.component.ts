import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AddInsuranceProductsComponent } from '../add-insurance-products/add-insurance-products.component';
import { Router, ActivatedRoute } from '@angular/router';
import { AddProductCategoryComponent } from '../add-product-category/add-product-category.component';
import { ViewInsuranceBenefitsComponent } from '../view-insurance-benefits/view-insurance-benefits.component';
import { AddProductSubCategoryComponent } from '../add-product-sub-category/add-product-sub-category.component';


@Component({
  selector: 'app-ins-product-sub-categories',
  templateUrl: './ins-product-sub-categories.component.html',
  styleUrls: ['./ins-product-sub-categories.component.scss'],
  providers: [DatePipe]
})
export class InsProductSubCategoriesComponent implements OnInit , OnChanges{
  @Input() category;
  public product_id: any;
  public isLoaded = false;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
        { name: 'viewrecord', title: '<i class="fa fa-eye"> Benefits</i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      sub_category_name: {
        title: 'Sub Category Name',
        type: 'string'
      },
      rate: {
        title: 'Premium Rate(%)',
        type: 'string'
      }
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _activatedRoute: ActivatedRoute, private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe, public toastrService: ToastrService, public router: Router) { }
  ngOnInit() {
    this.loadData();
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log( this.category);
    this.loadData();
  }
  private loadData(): any {
    this._httpService.model.entity = 'sub_category';
    this._httpService.model.where_clause = 'category_id';
    this._httpService.model.where_value = String(this.category.category_id);
    this._httpService.model.transaction_type = '10071';

    this._httpService.post('', this._httpService.model).subscribe(
      result => {
        this.dataSet = result.list;
      },
      error => {
      },
      complete => {
        this.isLoaded = true;
      }
    );
  }
  public openModal(parentData: any) {
     this.modalRef = this.modalService.open(AddProductSubCategoryComponent);
    this.modalRef.componentInstance.title = 'Add Sub Category';
    this.modalRef.componentInstance.category = this.category;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public editRecord(formData: any) {
    // this.modalRef = this.modalService.open(CreateAssessmentComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.componentInstance.title = 'Edit User: ' + formData.username;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('profile/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }


  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        this.viewInsuranceBenefits(event.data);
        break;
      case 'editrecord':
        this.editRecord(event.data);
    }
  }
  private viewInsuranceBenefits(data: any): void {
    this.modalRef = this.modalService.open(ViewInsuranceBenefitsComponent);
    this.modalRef.componentInstance.title = data.sub_category_name + ' Benefits';
    this.modalRef.componentInstance.category = data;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }

}
