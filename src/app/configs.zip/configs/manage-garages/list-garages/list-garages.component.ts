import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AddGarageComponent } from '../add-garage/add-garage.component';

@Component({
  selector: 'app-list-garages',
  templateUrl: './list-garages.component.html',
  styleUrls: ['./list-garages.component.scss'],
  providers: [DatePipe]
})
export class ListGaragesComponent implements OnInit {


  public isLoaded = false;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: true,
      custom: [
        { name: 'viewrecord', title: '<i class="fa fa-eye text-center mr-2"></i>View ' },
      //  { name: 'editrecord', title: '&nbsp;&nbsp;<i class="fa  fa-pencil"></i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      garage_name: {
        title: 'Garage Name',
        type: 'string'
      },

      garage_location: {
        title: 'Location',
        type: 'string'
      },
      garage_longitude: {
        title: 'Longitude',
        type: 'string'
      },
      garage_latitude: {
        title: 'Latitude',
        type: 'string'
      },

    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe, public toastrService: ToastrService, public router: Router) { }
  ngOnInit() {
    this.loadData();
  }
  private loadData(): any {
    this._httpService.model.entity = 'garage';
    this._httpService.model.where_clause = '';
    this._httpService.model.where_value = '';
    this._httpService.model.transaction_type = '10071';

    this._httpService.post('', this._httpService.model).subscribe(
      result => {
        this.dataSet = result.list;
      },
      error => {
      },
      complete => {
        this.isLoaded = true;
      }
    );
  }
  public openModal(parentData: any) {
     this.modalRef = this.modalService.open(AddGarageComponent);
    this.modalRef.componentInstance.title = 'Add Garage';
    this.modalRef.componentInstance.parentData = '';
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  onSelect($event): void{}
  onCustomAction($event): void{}
}
