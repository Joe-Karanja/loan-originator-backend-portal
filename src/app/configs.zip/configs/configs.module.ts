import {AddRoleComponent} from './rbac/roles/add-role/add-role.component';
import {RolesListComponent} from './rbac/roles/roles-list/roles-list.component';
import {AddDepartmentComponent} from './departments/add-department/add-department.component';
import {DepartmentsListComponent} from './departments/departments-list/departments-list.component';
// tslint:disable-next-line:max-line-length
import {ListInsuranceCoverTypesComponent} from './insurance/companies/insurance-cover-types/list-insurance-cover-types/list-insurance-covers.component';
// tslint:disable-next-line:max-line-length
import {AddInsuranceCoverAssignmentComponent} from './insurance/companies/cover-types/add-cover-type/add-insurance-cover-assignment.component';
import {AddInsuranceCompanyComponent} from './insurance/companies/add-insurance-company/add-insurance-company.component';
import {NgModule} from '@angular/core';
import {ModalModule} from 'ngx-bootstrap/modal';
import {ConfigsRoutingModule} from './configs-routing';
import {SharedModule} from '../shared/shared.module';
import {CountriesListComponent} from './countries/countries-list/countries-list.component';
import {AddCountryComponent} from './countries/add-country/add-country.component';
import {ListInsuranceCompaniesComponent} from './insurance/companies/list-insurance-companies/list-insurance-companies.component';
import {ListCoversComponent} from './insurance/companies/cover-types/list-covers/list-covers.component';
// tslint:disable-next-line:max-line-length
import {AddInsuranceCoverTypeComponent} from './insurance/companies/insurance-cover-types/add-insurance-cover-type/add-insurance-cover-type.component';
import {ViewInsuranceCompanyComponent} from './insurance/companies/view-insurance-company/view-insurance-company.component';
import {ListProfilesComponent} from './rbac/profiles/list-profiles/list-profiles.component';
import {AddProfileComponent} from './rbac/profiles/add-profile/add-profile.component';
import {ViewProfileComponent} from './rbac/profiles/view-profile/view-profile.component';
import {ListCurrenciesComponent} from './currencies/list-currencies/list-currencies.component';
import {AddCurrencyComponent} from './currencies/add-currency/add-currency.component';
import {ViewCurrencyComponent} from './currencies/view-currency/view-currency.component';
import {ViewCoveredPatientsComponent} from './insurance/companies/view-covered-patients/view-covered-patients.component';
import {AddCoveredPatientComponent} from './insurance/companies/view-covered-patients/add-covered-patient/add-covered-patient.component';
// tslint:disable-next-line:max-line-length
import {ListCoveredPatientsComponent} from './insurance/companies/view-covered-patients/list-covered-patients/list-covered-patients.component';
import {ViewMembersInDepartmentComponent} from './departments/view-members-in-department/view-members-in-department.component';
import {AssignUserToDepartmentComponent} from './departments/assign-user-to-department/assign-user-to-department.component';
import {ListLanguagesComponent} from './languages/list-languages/list-languages.component';
import {LanguageAddComponent} from './languages/language-add/language-add.component';
import {ListUssdServicesComponent} from './ussd-services/list-ussd-services/list-ussd-services.component';
import {AddUssdServiceComponent} from './ussd-services/add-ussd-service/add-ussd-service.component';
import {AssignUserToProfileComponent} from './rbac/profiles/view-profile/assign-user-to-profile/assign-user-to-profile.component';
import {ListInsuranceProductsComponent} from './manage-insurance-products/list-insurance-products/list-insurance-products.component';
import {AddInsuranceProductsComponent} from './manage-insurance-products/add-insurance-products/add-insurance-products.component';
import {ViewInsuranceProductComponent} from './manage-insurance-products/view-insurance-product/view-insurance-product.component';
import {AddProductCategoryComponent} from './manage-insurance-products/add-product-category/add-product-category.component';
// tslint:disable-next-line:max-line-length
import {InsProductSubCategoriesComponent} from './manage-insurance-products/ins-product-sub-categories/ins-product-sub-categories.component';
import {ViewInsuranceBenefitsComponent} from './manage-insurance-products/view-insurance-benefits/view-insurance-benefits.component';
import {AddProductSubCategoryComponent} from './manage-insurance-products/add-product-sub-category/add-product-sub-category.component';
import {AddBenefitComponent} from './manage-insurance-products/add-benefit/add-benefit.component';
import {ListGaragesComponent} from './manage-garages/list-garages/list-garages.component';
import {AddGarageComponent} from './manage-garages/add-garage/add-garage.component';
import {ListInvestmentProductsComponent} from './manage-investment-products/list-investment-products/list-investment-products.component';
import {AddInvestmentProductComponent} from './manage-investment-products/add-investment-product/add-investment-product.component';
import {ViewInvestmentProductCategoriesComponent} from './manage-investment-products/view-investment-product-categories/view-investment-product-categories.component';
import {AddInvestmentCategoryComponent} from './manage-investment-products/add-investment-category/add-investment-category.component';
import {ViewProductBenefitsComponent} from './manage-investment-products/view-product-benefits/view-product-benefits.component';
import {AddInvestmentBenefitComponent} from './manage-investment-products/add-investment-benefit/add-investment-benefit.component';
import {ListLoanProductsComponent} from './manage-loan-products/list-loan-products/list-loan-products.component';
import {AddLoanProductComponent} from './manage-loan-products/add-loan-product/add-loan-product.component';
import {AddRiskGroupComponent} from './manage-scoring-criteria/risk-group/add-risk-group/add-risk-group.component';
import {ListRiskGroupComponent} from './manage-scoring-criteria/risk-group/list-risk-group/list-risk-group.component';
// tslint:disable-next-line:max-line-length
import {ListQualificationCriteriaComponent} from './manage-qualification-criteria/qualification-criteria/list-qualification-criteria/list-qualification-criteria.component';
// tslint:disable-next-line:max-line-length
import {AddQualificationCriteriaComponent} from './manage-qualification-criteria/qualification-criteria/add-qualification-criteria/add-qualification-criteria.component';
import {ListLoanScoringGroupComponent} from './manage-scoring-criteria/scoring-group/list-loan-scoring-group/list-loan-scoring-group.component';
import {AddLoanScoringGroupComponent} from './manage-scoring-criteria/scoring-group/add-loan-scoring-group/add-loan-scoring-group.component';
import { ListScoringParameterComponent } from './manage-scoring-criteria/score-parameter/list-scoring-parameter/list-scoring-parameter.component';
import {AddScoringParameterComponent} from './manage-scoring-criteria/score-parameter/add-scoring-parameter/add-scoring-parameter.component';
import {ListScoringParamItemComponent} from './manage-scoring-criteria/score-parameter-item/list-scoring-param-item/list-scoring-param-item.component';
import {AddScoringParamItemComponent} from './manage-scoring-criteria/score-parameter-item/add-scoring-param-item/add-scoring-param-item.component';
import {ListQualificationParamsComponent} from './manage-qualification-criteria/qualification-params/list-qualification-params/list-qualification-params.component';
import {AddQualificationParamsComponent} from './manage-qualification-criteria/qualification-params/add-qualification-params/add-qualification-params.component';
import {CbBaseRateComponent} from './manage-cb-base-rate/cb-base-rate/cb-base-rate.component';
import {AddScoringMatrixComponent} from './manage-scoring-criteria/scoring-matrix/add-scoring-matrix/add-scoring-matrix.component';
import {ListScoringMatrixComponent} from './manage-scoring-criteria/scoring-matrix/list-scoring-matrices/list-scoring-matrix.component';
import {ListIndividualLoanScoringMatrixComponent} from './manage-scoring-criteria/scoring-matrix/list-individual-loan-scoring-matrices/list-individual-loan-scoring-matrix.component';
import {AddIndividualParameterItemsComponent} from './manage-scoring-criteria/scoring-matrix/list-individual-loan-scoring-matrices/individual-score-parameter-item/add-individual-parameter-items/add-individual-parameter-items.component';
import {ListIndividualScoringParamItemComponent} from './manage-scoring-criteria/scoring-matrix/list-individual-loan-scoring-matrices/individual-score-parameter-item/list-individual-scoring-param-item/list-individual-scoring-param-item.component';
import {AddMandatoryChecksComponent} from './manage-qualification-criteria/mandatory-checks/add-mandatory-checks/add-mandatory-checks.component';
import {ListMandatoryChecksComponent} from './manage-qualification-criteria/mandatory-checks/list-mandatory-checks/list-mandatory-checks.component';
import {AddRevenueShareEntityComponent} from './manage-revenue-share/add-revenue-share-entity/add-revenue-share-entity.component';
import {ListRevenueShareEntitiesComponent} from './manage-revenue-share/list-revenue-share-entity/list-revenue-share-entities.component';


// import { AddPatientComponent } from './add-patient/add-patient.component';

@NgModule({
    imports: [
        SharedModule,
        ConfigsRoutingModule,
        ModalModule.forRoot()
    ],
    declarations: [
        CountriesListComponent,
        AddCountryComponent,
        ListInsuranceCompaniesComponent,
        ListCoversComponent,
        AddInsuranceCompanyComponent,
        AddInsuranceCoverAssignmentComponent,
        AddInsuranceCoverTypeComponent,
        ViewInsuranceCompanyComponent,
        ListInsuranceCoverTypesComponent,
        DepartmentsListComponent,
        AddDepartmentComponent,
        RolesListComponent,
        AddRoleComponent,
        ListProfilesComponent,
        AddProfileComponent,
        ViewProfileComponent,
        ListCurrenciesComponent,
        AddCurrencyComponent,
        ViewCurrencyComponent,
        ViewCoveredPatientsComponent,
        ListCoveredPatientsComponent,
        AddCoveredPatientComponent,
        ViewMembersInDepartmentComponent,
        AssignUserToDepartmentComponent,
        ListLanguagesComponent,
        LanguageAddComponent,
        ListUssdServicesComponent,
        AddUssdServiceComponent,
        AssignUserToProfileComponent,
        ListInsuranceProductsComponent,
        AddInsuranceProductsComponent,
        ViewInsuranceProductComponent,
        AddProductCategoryComponent,
        InsProductSubCategoriesComponent,
        ViewInsuranceBenefitsComponent,
        AddProductSubCategoryComponent,
        AddBenefitComponent,
        ListGaragesComponent,
        AddGarageComponent,
        ListInvestmentProductsComponent,
        AddInvestmentProductComponent,
        ViewInvestmentProductCategoriesComponent,
        AddInvestmentCategoryComponent,
        ViewProductBenefitsComponent,
        AddInvestmentBenefitComponent,
        ListLoanProductsComponent,
        AddLoanProductComponent,


        AddScoringMatrixComponent,
        ListScoringMatrixComponent,

        ListRiskGroupComponent,
        AddRiskGroupComponent,
        ListLoanScoringGroupComponent,
        AddLoanScoringGroupComponent,
        ListScoringParameterComponent,
        AddScoringParameterComponent,
        AddScoringParamItemComponent,
        ListScoringParamItemComponent,
        AddScoringParamItemComponent,
        ListQualificationCriteriaComponent,
        AddQualificationCriteriaComponent,

        ListQualificationParamsComponent,
        AddQualificationParamsComponent,

        CbBaseRateComponent,

        ListIndividualLoanScoringMatrixComponent,

        ListIndividualScoringParamItemComponent,
        AddIndividualParameterItemsComponent,

        AddMandatoryChecksComponent,
        ListMandatoryChecksComponent,

        ListRevenueShareEntitiesComponent,
        AddRevenueShareEntityComponent

    ],
    entryComponents: [
        AddCountryComponent,
        AddInsuranceCompanyComponent,
        AddInsuranceCoverAssignmentComponent,
        AddInsuranceCoverTypeComponent,
        ViewInsuranceCompanyComponent,
        AddDepartmentComponent,
        AddRoleComponent,
        AddProfileComponent,
        AssignUserToProfileComponent,
        ViewProfileComponent,
        AddCurrencyComponent,
        ViewCurrencyComponent,
        ViewCoveredPatientsComponent,
        ViewMembersInDepartmentComponent,
        LanguageAddComponent,
        AddUssdServiceComponent,
        AddInsuranceProductsComponent,
        AddProductCategoryComponent,
        ViewInsuranceBenefitsComponent,
        AddProductSubCategoryComponent,
        AddBenefitComponent,
        AddGarageComponent,
        AddInvestmentProductComponent,
        AddInvestmentCategoryComponent,
        ViewProductBenefitsComponent,
        AddInvestmentBenefitComponent,
        AddLoanProductComponent,


        AddScoringMatrixComponent,
        ListScoringMatrixComponent,

        ListRiskGroupComponent,
        AddRiskGroupComponent,
        ListLoanScoringGroupComponent,
        AddLoanScoringGroupComponent,
        ListScoringParameterComponent,
        AddScoringParameterComponent,
        AddScoringParamItemComponent,
        ListScoringParamItemComponent,
        AddScoringParamItemComponent,

        ListQualificationCriteriaComponent,
        AddQualificationCriteriaComponent,
        ListQualificationParamsComponent,
        AddQualificationParamsComponent,

        CbBaseRateComponent,

        ListIndividualLoanScoringMatrixComponent,



        ListIndividualScoringParamItemComponent,
        AddIndividualParameterItemsComponent,

        // AddMandatoryChecksComponent,
        ListMandatoryChecksComponent,

        ListRevenueShareEntitiesComponent,
        AddRevenueShareEntityComponent
    ],
})
export class ConfigsModule {
}

