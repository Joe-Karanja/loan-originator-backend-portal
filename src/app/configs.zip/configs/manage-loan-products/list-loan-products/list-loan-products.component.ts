import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AddLoanProductComponent } from '../add-loan-product/add-loan-product.component';

@Component({
  selector: 'app-list-loan-products',
  templateUrl: './list-loan-products.component.html',
  styleUrls: ['./list-loan-products.component.scss'],
  providers: [DatePipe]
})
export class ListLoanProductsComponent implements OnInit {


  public isLoaded = false;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
        //  { name: 'viewrecord', title: '<i class="fa fa-eye text-center mr-2"></i>View ' },
        { name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil fa-lg" style="text-decoration: none"></i> &nbsp;' },
        { name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg" style="text-decoration: none"></i> &nbsp;' }

      ],
      position: 'right'
    },
    // delete: {
    //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
    //   confirmDelete: true
    // },
    noDataMessage: 'No data found',
    columns: {
      productName: {
        title: 'ProductName',
        type: 'string',
        filter: false
      },
      // productCode: {
      //   title: 'Product Code',
      //   type: 'string'
      // },
      interestRate: {
        title: 'InterestRate',
        type: 'string',
        filter: false
      },
      processingRate: {
        title: 'ProcessingRate',
        type: 'string',
        filter: false
      },
      penaltyMode: {
        title: 'PenaltyMode',
        type: 'string',
        filter: false
      },
      penaltyRate: {
        title: 'PenaltyRate',
        type: 'string',
        filter: false
      },
      // disbursementAccount: {
      //   title: 'Disbursement Account',
      //   type: 'string',
      //   filter: false
      // },
      // collectionAcount: {
      //   title: 'Collection Account',
      //   type: 'string'
      // },
      minimumScore: {
        title: 'MinScore',
        type: 'string',
        filter: false
      },
      minPeriod: {
        title: 'MinPeriod',
        type: 'string',
        filter: false,
        valuePrepareFunction: (value) => {
          return value + ' month(s)';
        },
      },
      maxPeriod: {
        title: 'MaxPeriod',
        type: 'string',
        filter: false,
        valuePrepareFunction: (value) => {
          return value + ' month(s)';
        },
      },
      type: {
        title: 'LoanType',
        type: 'string',
        filter: false
      },
      // scoringMatrix: {
      //   title: 'Scoring Matrix ID',
      //   type: 'number',
      //   valuePrepareFunction: (value) => {
      //     return value.name;
      //   },
      //
      // },
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
              public datePipe: DatePipe, public toastrService: ToastrService, public router: Router) { }
  ngOnInit() {
    this.loadData();
  }
  private loadData(): any {


    this._httpService.scoresGet('loans/products').subscribe(
      result => {
        this.dataSet = result.data;
      },
      error => {
      },
      complete => {
        this.isLoaded = true;
      }
    );
  }
  public openModal(parentData: any, editing: boolean) {
     this.modalRef = this.modalService.open(AddLoanProductComponent, {size: 'lg'});
     this.modalRef.componentInstance.title = editing ? 'Edit Loan Product' : 'Add Loan Product';
     this.modalRef.componentInstance.formData = parentData;

     this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }

  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('profile/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }


  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        //   this.viewInsuranceProduct(event.data);
        break;
      case 'editrecord':
        this.editRecord(event.data);
        break;
      case 'deleterecord':
        this.deleteLoanProduct(event.data);
        break;
    }
  }
  private viewInsuranceProduct(data: any): void {
    this.router.navigate(['configs/investment-products', data.product_id]);
  }

  deleteLoanProduct(data) {
    console.log('deleted loan product.');
    console.log(data);
  }

  editRecord(data) {
    console.log('edited loan product.');
    console.log(data);
    this.openModal(data, true);
  }

}
