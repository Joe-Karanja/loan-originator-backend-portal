import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {HttpService} from 'src/app/shared/services/http.service';
import {ToastrService} from 'ngx-toastr';

@Component({
    selector: 'app-add-loan-product',
    templateUrl: './add-loan-product.component.html',
    styleUrls: ['./add-loan-product.component.scss']
})
export class AddLoanProductComponent implements OnInit {

    @Input() title;
    @Input() formData;
    public loading = false;
    public hasErrors = false;
    public errorMessages;
    public form: FormGroup;
    public scoringMatrices: any;

    constructor(
        public activeModal: NgbActiveModal,
        public fb: FormBuilder,
        private _httpService: HttpService,
        public toastrService: ToastrService) {

      this.loadScoringMatrices();
    }

    ngOnInit() {
        this.form = this.fb.group({
            productName: [this.formData ? this.formData.productName : '', [Validators.required]],
            productCode: [this.formData ? this.formData.productCode : '', [Validators.required]],
            interestRate: [this.formData ? this.formData.interestRate : '', [Validators.required]],
            processingRate: [this.formData ? this.formData.processingRate : '', [Validators.required]],
            penaltyMode: [this.formData ? this.formData.penaltyMode : '', [Validators.required]],
            penaltyRate: [this.formData ? this.formData.penaltyRate : '', [Validators.required]],
            disbursementAccount: [this.formData ? this.formData.disbursementAccount : '', [Validators.required]],
            collectionAccount: [this.formData ? this.formData.collectionAccount : '', [Validators.required]],
            minimumScore: [this.formData ? this.formData.minimumScore : '', [Validators.required]],
            minPeriod: [this.formData ? this.formData.minPeriod : '', [Validators.required]],
            maxPeriod: [this.formData ? this.formData.maxPeriod : '', [Validators.required]],
            type: [this.formData ? this.formData.type : '', [Validators.required]],
            scoringMatrixId: [this.formData ? this.formData.scoringMatrixId : 0, [Validators.required]],


        });
        if (this.formData) {
        }
    }

    public submitData(): void {

        if (this.formData) {
            this.saveChanges();
        } else {
            this.createRecord();
        }
        this.loading = true;
    }

    public closeModal(): void {
        this.activeModal.dismiss('Cross click');
    }

    private createRecord(): any {


        this._httpService.scoresPost('loans/create/product', this.form.value).subscribe(
            result => {
                if (result.status === 200) {
                    this.toastrService.success('Record created successfully!', 'Created Successfully!');
                    this.activeModal.close('success');
                } else {
                    this.toastrService.error('Failed to create!', 'Failed!');
                }
            },
            error => {
            },
            complete => {
                this.loading = false;
            }
        );
    }

    private saveChanges(): any {
        this._httpService.scoresPost('loans/update/product', {...this.form.value, id: this.formData.id }).subscribe(
            result => {
                if (result.status === 200) {
                    this.toastrService.success('Changes saved successfully!', 'Saved Changes!');
                    this.activeModal.close('success');
                } else {
                    this._httpService.handleErrorsFromServer(result.errors);
                }
            },
            error => {
                this.loading = false;
                this.errorMessages = error.error.error_messages;
            },
            complete => {
                this.loading = false;
            }
        );
    }

  private loadScoringMatrices() {
    this._httpService.scoresGet('scoring/matrices').subscribe(
        result => {
          this.scoringMatrices = result.data;
        }
    );
  }
}
