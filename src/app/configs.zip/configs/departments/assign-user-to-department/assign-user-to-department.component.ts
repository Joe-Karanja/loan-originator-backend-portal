import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-user-to-department',
  templateUrl: './assign-user-to-department.component.html',
  styleUrls: ['./assign-user-to-department.component.scss']
})
export class AssignUserToDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
