import { ViewMembersInDepartmentComponent } from './../view-members-in-department/view-members-in-department.component';
import { AddDepartmentComponent } from './../add-department/add-department.component';
import { DatePipe } from '@angular/common';
import { HttpService } from './../../../shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-departments-list',
  templateUrl: './departments-list.component.html',
  styleUrls: ['./departments-list.component.scss'],
  providers: [DatePipe]
})
export class DepartmentsListComponent implements OnInit {
  public dataSet: any;
  public searchText: string;
  @Input() data;
  public formData;
  public modalRef: NgbModalRef;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe) { }

  ngOnInit() {
    this.loadData();
  }
  private loadData(): any {
    this._httpService.get('departments').subscribe(
      result => {
        if (result.response_code === 200) {
          this.dataSet = result.data.map(obj => {
            return obj;
          });
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }
  public openModal(formData) {
    this.formData = formData;
    this.modalRef = this.modalService.open(AddDepartmentComponent);
    if (formData) {
      this.modalRef.componentInstance.title = 'Edit Company: ';
    } else {
      this.modalRef.componentInstance.title = 'Add Insurance Company';
    }
    this.modalRef.componentInstance.formData = this.formData;
    this.modalRef.componentInstance.visitData = this.data;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }

  public  showMembers(department: any) {
    this.modalRef = this.modalService.open(ViewMembersInDepartmentComponent);
      this.modalRef.componentInstance.title = 'Members in ' + department.department_name;
    this.modalRef.componentInstance.department = department;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
}
