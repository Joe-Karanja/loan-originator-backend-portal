import { HttpService } from 'src/app/shared/services/http.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-cover-type',
  templateUrl: './add-cover-type.component.html',
  styleUrls: ['./add-cover-type.component.scss']
})
export class AddInsuranceCoverTypeComponent implements OnInit {
    @Input() title;
    @Input() formData;
    @Input() visitData;
    public loading = false;
    public hasErrors = false;
    public errorMessages;
    public form: FormGroup;
    constructor(
      public activeModal: NgbActiveModal,
      public fb: FormBuilder,
      private _httpService: HttpService,
      public toastrService: ToastrService) { }
    ngOnInit() {
      this.form = this.fb.group({
        type_name: [this.formData ? this.formData.company_name : '', Validators.compose([Validators.required])],
        description: [this.formData ? this.formData.description : '', Validators.compose([Validators.required])]
      });
    }
    submitData(): void {
      this.loading = true;
      this._httpService.post('insurance/covertype/add', this.form.value).subscribe(
        result => {
          if (result.response_code === 200) {
            this.toastrService.success('Record created successfully!', 'Created Successfully!');
            this.activeModal.close('success');
          } else {
            this.handleErrorsFromServer(result);
          }
        },
        error => {
          this.errorMessages = error.error.error_messages;
        },
        complete => {
          this.loading = false;
        }
      );
    }
    public handleErrorsFromServer(response: any) {
      this.loading = false;
      this.hasErrors = true;
      this.errorMessages = [];
      Object.entries(response.error_messages).forEach(
        ([key, value]) => // console.log(key, value)
          this.errorMessages.push(value)
      );
    }

    public closeModal(): void {
      this.activeModal.dismiss('Cross click');
    }
}
