import { AddInsuranceCoverTypeComponent } from './../add-insurance-cover-type/add-insurance-cover-type.component';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-list-isurance-cover-types',
  templateUrl: './list-covers.component.html',
  styleUrls: ['./list-covers.component.scss'],
  providers: [DatePipe]
})
export class ListInsuranceCoverTypesComponent implements OnInit {

  @Input() data;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: true,
      custom: [{ name: 'viewRecord', title: '<i class="fa fa-eye text-center mr-2"></i>View ' }],
      position: 'right' // left|right
    },
    delete: {
      deleteButtonContent: '<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      type_name: {
        title: 'Cover Type',
        type: 'string'
      },
      description: {
        title: 'Description',
        type: 'string'
      },
      active: {
        title: 'Active',
        type: 'string'
      },
      created_at: {
        title: 'Created On',
        type: 'string',
        valuePrepareFunction: (date) => {
          const raw = new Date(date);
          const formatted = this.datePipe.transform(raw, 'dd MMM yyyy');
          return formatted;
        },
      },
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
    constructor(private _httpService: HttpService, private modalService: NgbModal,
       public datePipe: DatePipe) { }
    ngOnInit() {
    this.loadData();
    }
    private loadData(): any {
      this._httpService.get('insurance/covertypes').subscribe(
        result => {
          if (result.response_code === 200) {
            this.dataSet = result.data.map(obj => {
              return obj;
            });
          } else {
          }
        },
        error => {
        },
        complete => {
        }
      );
    }
    public openModal(formData) {
      this.formData = formData;
      this.modalRef = this.modalService.open(AddInsuranceCoverTypeComponent);
      if (formData) {
        this.modalRef.componentInstance.title = 'Edit Insurance Cover Type: ';
      } else {
        this.modalRef.componentInstance.title = 'Add Insurance Cover Type';
      }
      this.modalRef.componentInstance.formData = this.formData;
      this.modalRef.componentInstance.visitData = this.data;
      this.modalRef.result.then((result) => {
        if (result === 'success') {
          this.loadData();
        }
      }, (reason) => {
      });
    }

}
