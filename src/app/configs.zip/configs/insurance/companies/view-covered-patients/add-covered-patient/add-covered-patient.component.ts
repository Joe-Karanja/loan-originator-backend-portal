import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-covered-patient',
  templateUrl: './add-covered-patient.component.html',
  styleUrls: ['./add-covered-patient.component.scss']
})
export class AddCoveredPatientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
