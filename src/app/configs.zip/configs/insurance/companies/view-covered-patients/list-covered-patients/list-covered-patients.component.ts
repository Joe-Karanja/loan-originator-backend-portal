import { AddCoveredPatientComponent } from './../add-covered-patient/add-covered-patient.component';
import { LabelBooleanComponent } from 'src/app/shared/components/label-boolean/label-boolean.component';
import { DatePipe } from '@angular/common';

import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-list-covered-patients',
  templateUrl: './list-covered-patients.component.html',
  styleUrls: ['./list-covered-patients.component.scss'],
  providers: [DatePipe]
})
export class ListCoveredPatientsComponent implements OnInit {

  @Input() companyData;
  @Input() treatments;
  public activeTreatment;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: true,
      custom: [
        { name: 'viewrecord', title: '<i class="fa fa-eye text-center mr-2"></i>View ' },
        { name: 'editrecord', title: '&nbsp;&nbsp;<i class="fa  fa-pencil"></i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      is_paid: {
        title: 'Should Be Paid',
        type: 'custom',
        renderComponent: LabelBooleanComponent
      },
      medicine_name: {
        title: 'Medicine',
        type: 'string'
      },
      dosage: {
        title: 'Dosage',
        type: 'string'
      },
     /* quantity: {
        title: 'Quantity',
        type: 'string'
      },
      daily_count: {
        title: 'Daily Dosage',
        type: 'string'
      }, */
      unit: {
        title: 'unit',
        type: 'string'
      },
      recommended_prescription: {
        title: 'Prescription',
        type: 'string'
      },
      created_at: {
        title: 'Created On',
        type: 'string',
        valuePrepareFunction: (date) => {
          const raw = new Date(date);
          const formatted = this.datePipe.transform(raw, 'dd MMM yyyy');
          return formatted;
        },
      },
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe, public toastrService: ToastrService) { }
  ngOnInit() {
    this.activeTreatment = this.treatments[0];
    this.loadData();
  }
  private loadData(): any {
    this._httpService.get('treatment/prescription/' + this.activeTreatment.id + '/list').subscribe(
      result => {
        if (result.response_code === 200) {
          this.dataSet = result.data.map(obj => {
            obj.dosage = obj.quantity + ' * ' + obj.daily_count;
            return obj;
          });
          console.log( this.dataSet);
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }
  public openModal(parentData: any) {
    this.modalRef = this.modalService.open(AddCoveredPatientComponent);
    this.modalRef.componentInstance.title = 'Add Patient';
    this.modalRef.componentInstance.parentData = this.companyData;
    this.modalRef.componentInstance.activeTreatmentData = this.activeTreatment;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public editRecord(formData: any) {
    this.modalRef = this.modalService.open(AddCoveredPatientComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.componentInstance.title = 'Edit Cover: ';
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('test/' + event.data.category_id + '/test/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }
  public viewRecord(formData: any) {
    this.modalRef = this.modalService.open(AddCoveredPatientComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
      }
    }, (reason) => {
    });
  }

  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        this.viewRecord(event.data);
        break;
      case 'editrecord':
        this.editRecord(event.data);
    }
  }


}
