import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-view-covered-patients',
  templateUrl: './view-covered-patients.component.html',
  styleUrls: ['./view-covered-patients.component.scss']
})
export class ViewCoveredPatientsComponent implements OnInit {

  @Input() companyData;
  details: any;
  constructor( public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.details = this.companyData;
  }

}
