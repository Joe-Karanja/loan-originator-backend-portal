import { ViewCoveredPatientsComponent } from './../view-covered-patients/view-covered-patients.component';
import { ViewInsuranceCompanyComponent } from './../view-insurance-company/view-insurance-company.component';
import { AddInsuranceCompanyComponent } from './../add-insurance-company/add-insurance-company.component';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-list-insurance-companies',
  templateUrl: './list-insurance-companies.component.html',
  styleUrls: ['./list-insurance-companies.component.scss'],
  providers: [DatePipe]
})
export class ListInsuranceCompaniesComponent implements OnInit {
  @Input() data;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: true,
      custom: [  { name: 'viewrecord', title: '<i class="fa fa-eye text-center mr-2"></i>View &nbsp;&nbsp;&nbsp;' },
      { name: 'viewPatients', title: '&nbsp;&nbsp;<i class="fa fa-users"></i>' }],
      position: 'right' // left|right
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      company_name: {
        title: 'Company Name',
        type: 'string'
      },
      location: {
        title: 'Location',
        type: 'string'
      },
      phone_number: {
        title: 'Phone Number',
        type: 'string'
      },
      alt_phone_number: {
        title: 'Alt Phone Number',
        type: 'string'
      },
      postal_address: {
        title: 'Postal Address',
        type: 'string'
      },
      email_address: {
        title: 'Email Address',
        type: 'string'
      },
      postal_code: {
        title: 'Postal Code',
        type: 'string'
      },
      active: {
        title: 'Active',
        type: 'string'
      },
      created_at: {
        title: 'Created On',
        type: 'string',
        valuePrepareFunction: (date) => {
          const raw = new Date(date);
          const formatted = this.datePipe.transform(raw, 'dd MMM yyyy');
          return formatted;
        },
      },
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
    constructor(private _httpService: HttpService, private modalService: NgbModal,
       public datePipe: DatePipe) { }
    ngOnInit() {
    this.loadData();
    }
    private loadData(): any {
      this._httpService.get('insurances').subscribe(
        result => {
          if (result.response_code === 200) {
            this.dataSet = result.data.map(obj => {
              return obj;
            });
          } else {
          }
        },
        error => {
        },
        complete => {
        }
      );
    }
    public openModal(formData) {
      this.formData = formData;
      this.modalRef = this.modalService.open(AddInsuranceCompanyComponent);
      if (formData) {
        this.modalRef.componentInstance.title = 'Edit Company: ';
      } else {
        this.modalRef.componentInstance.title = 'Add Insurance Company';
      }
      this.modalRef.componentInstance.formData = this.formData;
      this.modalRef.componentInstance.visitData = this.data;
      this.modalRef.result.then((result) => {
        if (result === 'success') {
          this.loadData();
        }
      }, (reason) => {
      });
    }
    public viewRecord(data: any) {
      this.modalRef = this.modalService.open(ViewInsuranceCompanyComponent, { backdrop: 'static' });
      this.modalRef.componentInstance.companyData = data;
      this.modalRef.result.then((result) => {
        if (result === 'success') {
          this.loadData();
        }
      }, (reason) => {
      });
    }
    public viewPatients(data: any) {
      this.modalRef = this.modalService.open(ViewCoveredPatientsComponent, { backdrop: 'static' });
      this.modalRef.componentInstance.companyData = data;
      this.modalRef.result.then((result) => {
        if (result === 'success') {
          this.loadData();
        }
      }, (reason) => {
      });
    }
    onCustomAction(event) {
      switch (event.action) {
        case 'viewrecord':
          this.viewRecord(event.data);
          break;
        case 'viewPatients':
          this.viewPatients(event.data);
      }
    }

}
