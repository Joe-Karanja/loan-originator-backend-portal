import { HttpService } from 'src/app/shared/services/http.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-insurance-cover-assignment',
  templateUrl: './add-cover-type.component.html',
  styleUrls: ['./add-cover-type.component.scss']
})
export class AddInsuranceCoverAssignmentComponent implements OnInit {
    @Input() title;
    @Input() formData;
    @Input() companyData;
    public loading = false;
    public hasErrors = false;
    public errorMessages;
    public covers;
    public form: FormGroup;
    constructor(
      public activeModal: NgbActiveModal,
      public fb: FormBuilder,
      private _httpService: HttpService,
      public toastrService: ToastrService) { }
    ngOnInit() {
      console.log(this.companyData);
      this.loadCovers();
      this.form = this.fb.group({
        cover_id  : [this.formData ? this.formData.cover_id   : '', Validators.compose([Validators.required])],
          });
    }
    submitData(): void {
      this.loading = true;
      this._httpService.post('insurance/' + this.companyData.id + '/cover/' + this.form.value.cover_id, this.form.value).subscribe(
        result => {
          if (result.response_code === 200) {
            this.toastrService.success('Record created successfully!', 'Created Successfully!');
            this.activeModal.close('success');
          } else {
            this.handleErrorsFromServer(result);
          }
        },
        error => {
          this.errorMessages = error.error.error_messages;
        },
        complete => {
          this.loading = false;
        }
      );
    }
    public handleErrorsFromServer(response: any) {
      this.loading = false;
      this.hasErrors = true;
      this.errorMessages = [];
      Object.entries(response.error_messages).forEach(
        ([key, value]) => // console.log(key, value)
          this.errorMessages.push(value)
      );
    }

    public closeModal(): void {
      this.activeModal.dismiss('Cross click');
    }
    loadCovers(): void {
      this._httpService.get('insurance/covertypes').subscribe(
        result => {
          if (result.response_code === 200) {
            this.covers = result.data;
            console.log(this.covers);
          } else {
          }
        },
        error => {
        },
        complete => {
        }
      );
    }

}
