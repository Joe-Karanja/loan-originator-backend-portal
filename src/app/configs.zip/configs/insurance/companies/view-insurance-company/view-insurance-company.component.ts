import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-view-insurance-company',
  templateUrl: './view-insurance-company.component.html',
  styleUrls: ['./view-insurance-company.component.scss']
})
export class ViewInsuranceCompanyComponent implements OnInit {
  @Input() companyData;
  details: any;
  constructor( public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.details = this.companyData;
  }
}
