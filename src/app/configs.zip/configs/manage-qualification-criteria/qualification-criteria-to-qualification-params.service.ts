import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {NavigationExtras} from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class QualificationCriteriaToQualificationParamsService {

    private qualificationCriteria = new BehaviorSubject(null);
    currentQualificationCriteria = this.qualificationCriteria.asObservable();

    constructor() {

    }

    updateApprovalMessage(message: NavigationExtras) {
        this.qualificationCriteria.next(message);
    }
}
