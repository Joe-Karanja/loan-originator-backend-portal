import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {NavigationExtras, Router} from '@angular/router';
import {AddQualificationCriteriaComponent} from '../../qualification-criteria/add-qualification-criteria/add-qualification-criteria.component';
import {QualificationCriteriaToQualificationParamsService} from '../../qualification-criteria-to-qualification-params.service';
import {AddQualificationParamsComponent} from '../add-qualification-params/add-qualification-params.component';


@Component({
    selector: 'app-list-loan-products',
    templateUrl: './list-qualification-params.component.html',
    styleUrls: ['./list-qualification-params.component.scss'],
    providers: [DatePipe]
})
export class ListQualificationParamsComponent implements OnInit {


    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                {name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil fa-lg" style="text-decoration: none"></i> &nbsp;'},
                // tslint:disable-next-line:max-line-length
                // {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg" style="text-decoration: none"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            product_id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },
            riskGrade: {
                title: 'Risk Grade',
                type: 'string',
                filter: false
            },
            rangeFrom: {
                title: 'Range From',
                type: 'number',
                filter: false
            },
            rangeTo: {
                title: 'Range To',
                type: 'number',
                filter: false
            },
            gradeDescription: {
                title: 'Grade Description',
                type: 'string',
                filter: false
            }

        },
        pager: {
            display: true,
            perPage: 15
        }
    };
    dataSet: any;
    message: any;

    constructor(private _httpService: HttpService,
                private modalService: NgbModal,
                public datePipe: DatePipe,
                public toastrService: ToastrService,
                public router: Router,
                private qualificationCriteriaToQualificationParamsService: QualificationCriteriaToQualificationParamsService) {
    }

    ngOnInit() {
        this.qualificationCriteriaToQualificationParamsService.currentQualificationCriteria.subscribe(msg => this.message = msg);
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean) {
        this.modalRef = this.modalService.open(AddQualificationParamsComponent);
        this.modalRef.componentInstance.title = editing ? 'Update Qualification Params' : 'Add Qualification Params';
        this.modalRef.componentInstance.formData = parentData;

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {

            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    private loadData(): any {

        this._httpService.scoresGet(`scoring/matrices`).subscribe(
            result => {

                this.dataSet = [{
                    id: 1,
                    riskGrade: 'A',
                    rangeFrom: 900,
                    rangeTo: 1000,
                    gradeDescription: 'CB Base rate (x%)'
                },
                    {
                        id: 2,
                        riskGrade: 'B',
                        rangeFrom: 800,
                        rangeTo: 900,
                        gradeDescription: 'CB Base rate + Margin of 1%'
                    },
                    {
                        id: 3,
                        riskGrade: 'C',
                        rangeFrom: 650,
                        rangeTo: 800,
                        gradeDescription: 'CB Base rate + Margin of 2%'
                    },
                    {
                        id: 4,
                        riskGrade: 'D',
                        rangeFrom: 501,
                        rangeTo: 650,
                        gradeDescription: 'CB Base rate + Margin of 3%'
                    },

                    {
                        id: 5,
                        riskGrade: 'E',
                        rangeFrom: 0,
                        rangeTo: 500,
                        gradeDescription: 'Not within acceptable threshold'
                    }
                ];
                    // result.data;
            },
            error => {
            },
            complete => {
                this.isLoaded = true;
            }
        );
    }

    private viewInsuranceProduct(data: any): void {
        this.router.navigate(['configs/investment-products', data.product_id]);
    }

}
