import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';
import {QualificationCriteriaToQualificationParamsService} from '../../qualification-criteria-to-qualification-params.service';
import {AddMandatoryChecksComponent} from '../add-mandatory-checks/add-mandatory-checks.component';


@Component({
    selector: 'app-list-loan-products',
    templateUrl: './list-mandatory-checks.component.html',
    styleUrls: ['./list-mandatory-checks.component.scss'],
    providers: [DatePipe]
})
export class ListMandatoryChecksComponent implements OnInit {


    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                {name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil fa-lg" style="text-decoration: none"></i> &nbsp;'},
                // tslint:disable-next-line:max-line-length
                // {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg" style="text-decoration: none"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            id: {
                title: '#',
                type: 'text',
                filter: false
            },
            stepAction: {
                title: 'Step Action',
                type: 'string',
                filter: false,
                valuePrepareFunction: (value) => {
                    return value;
                },
            },
            outcome: {
                title: 'Outcome',
                type: 'number',
                filter: false
            },
            action: {
                title: 'Action',
                type: 'number',
                filter: false
            }
        },
        pager: {
            display: true,
            perPage: 50
        }
    };
    dataSet: any;
    message: any;

    constructor(private _httpService: HttpService,
                private modalService: NgbModal,
                public datePipe: DatePipe,
                public toastrService: ToastrService,
                public router: Router,
                private qualificationCriteriaToQualificationParamsService: QualificationCriteriaToQualificationParamsService) {
    }

    ngOnInit() {
        this.qualificationCriteriaToQualificationParamsService.currentQualificationCriteria.subscribe(msg => this.message = msg);
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean) {
        this.modalRef = this.modalService.open(AddMandatoryChecksComponent);
        this.modalRef.componentInstance.title = editing ? 'Update Qualification Params' : 'Add Qualification Params';
        this.modalRef.componentInstance.formData = parentData;

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {

            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    private loadData(): any {

        this._httpService.scoresGet(`scoring/matrices`).subscribe(
            result => {

                this.dataSet = [
                    {
                        id: 1,
                        stepAction: 'Check Internal Blacklist',
                        outcome: 'Negative',
                        action: 'Automatic Decline',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'Positive',
                        action: 'Check Length of Relationship With Organisation',
                    },


                    {
                        id: 2,
                        stepAction: 'Length of Relationship With Organisation',
                        outcome: '<6 Months',
                        action: 'Decline (Complete All Actions in Step 2)',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: '>6 Months',
                        action: 'Check Arrears in Existing MIS',
                    },


                    {
                        id: 3,
                        stepAction: 'Arrears in Existing MIS',
                        outcome: 'Yes',
                        action: 'Decline (Complete All Actions in Step 2)',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'No',
                        action: 'Check CRB',
                    },


                    {
                        id: 4,
                        stepAction: 'CRB',
                        outcome: 'Negative',
                        action: 'Decline (Complete All Actions in Step 2)',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'Positive',
                        action: 'Check Default History in Last 12 Months',
                    },


                    {
                        id: 5,
                        stepAction: 'Maximum Defaulted Days in Last 12-months',
                        outcome: '>0',
                        action: 'Decline (Complete All Actions in Step 2)',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: '0',
                        action: 'Check Bureau Credit Score',
                    },


                    {
                        id: 6,
                        stepAction: 'Credit Score',
                        outcome: '<645',
                        action: 'Decline (Complete All Actions in Step 2)',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: '>645',
                        action: 'Check Internal Score',
                    },

                    {
                        id: 7,
                        stepAction: 'Score',
                        outcome: 'Delow Cut-off',
                        action: 'Decline',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'At/above  Cut-off',
                        action: 'Qualify for Amount',
                    },

                    {
                        id: 8,
                        stepAction: 'Seek Borrowers Application Within Assigned Qualified Amount',
                        outcome: 'If Not Within',
                        action: 'Decline',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'If Within',
                        action: 'Give Cost of Credit',
                    },

                    {
                        id: 9,
                        stepAction: 'Option to Accept Cost',
                        outcome: 'Not Accepted',
                        action: 'Decline',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'Accepted',
                        action: 'Lead to Accept Terms & Conditions',
                    },

                    {
                        id: 10,
                        stepAction: 'Terms and Conditions',
                        outcome: 'Not Accepted',
                        action: 'Decline',
                    },
                    {
                        id: '',
                        stepAction: '',
                        outcome: 'Accepted',
                        action: 'Disburse & Communicate to Client',
                    },

                ];
                // result.data;
            },
            error => {
            },
            complete => {
                this.isLoaded = true;
            }
        );
    }

    private viewInsuranceProduct(data: any): void {
        this.router.navigate(['configs/investment-products', data.product_id]);
    }

}
