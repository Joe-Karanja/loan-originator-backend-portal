import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-loan-product',
  templateUrl: './add-mandatory-checks.component.html',
  styleUrls: ['./add-mandatory-checks.component.scss']
})
export class AddMandatoryChecksComponent implements OnInit {

  @Input() title;
  @Input() formData;
  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;
  scoringParameters: any;
  qualificationCriteria: any;

  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }
  ngOnInit() {
    this.form = this.fb.group({
      qualificationCriteriaId: [this.formData ? this.formData.qualificationCriteriaId : '', [Validators.required]],
      scoringParameterId: [this.formData ? this.formData.scoringParameterId : '', [Validators.required]],
      minimumScore: [this.formData ? this.formData.minimumScore : '', [Validators.required]],
      description: [this.formData ? this.formData.description : '', [Validators.required]],

    });

    this.fetchScoringParameters();
    this.fetchQualificationCriteria();

  }

  public submitData(): void {

    if (this.formData) {
     this.saveChanges();
    } else {
      this.createRecord();
    }
    this.loading = true;
  }
  private createRecord(): any {


    this._httpService.scoresPost('scoring/criteria/params/create', this.form.value).subscribe(
      result => {
       if (result.status === 200) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.toastrService.error('Failed to create!', 'Failed!');
        }
      },
      error => {
      },
      complete => {
        this.loading = false;
      }

    );
  }
  private saveChanges(): any {
    this._httpService.put('user/' + this.formData.id, this.form.value).subscribe(
      result => {
        // if (result.response.response_code === this._httpService.errCodes.SUCCES_CODE) {
          this.toastrService.success('Changes saved successfully!', 'Saved Changes!');
          this.activeModal.close('success');
        // } else {
        //   this._httpService.handleErrorsFromServer(result.errors);
        // }
      },
      error => {
        this.loading = false;
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }


  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }

  private fetchScoringParameters() {
    this._httpService.scoresGet('scoring/parameters?size=5000&page=0&groupId=1').subscribe(
        result => {
            if (result.status === 200) {
                this.scoringParameters = result.data;
            } else {
                this.scoringParameters = [];
            }
        });
  }


  private fetchQualificationCriteria() {
    this._httpService.scoresGet('scoring/criteria/?page=0&size=5000').subscribe(
        result => {
          if (result.status === 200) {
            this.qualificationCriteria = result.data;
          } else {
           this.qualificationCriteria = [];
          }
        });
  }
}
