import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-loan-product',
  templateUrl: './add-qualification-criteria.component.html',
  styleUrls: ['./add-qualification-criteria.component.scss']
})
export class AddQualificationCriteriaComponent implements OnInit {

  @Input() title;
  @Input() formData;
  @Input() editing;

  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;
  public nextFromValue = 0;

  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }

    ngOnInit() {

    this.getHighestBandValue().then(r => {
      if (!this.editing) {
        this.nextFromValue = r;
      } else {
        this.nextFromValue = this.formData.valueFrom;
      }
    });
    this.form = this.fb.group({

      valueFrom: [this.formData ? this.formData.valueFrom : '', [Validators.required]],
      valueTo: [this.formData ? this.formData.valueTo : '', [Validators.required]],
      matrixId: [1],
      marginRate: [this.formData ? this.formData.marginRate : '', [Validators.required]],
      isPriceable: [true, [Validators.required]],
      rating: [this.formData ? this.formData.rating : '', [Validators.required]],


    });

  }

  public submitData(): void {

    if (this.formData) {
     this.saveChanges();
    } else {
      this.createRecord();
    }
    this.loading = true;
  }
  private createRecord(): any {

    this._httpService.scoresPost('scoring/criteria/create', this.form.value).subscribe(
      result => {
       if (result.status === 200) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.toastrService.error('Failed to create!', 'Failed!');
        }
      },
      error => {
      },
      complete => {
        this.loading = false;
      }

    );
  }
  private saveChanges(): any {
    this._httpService.scoresPost('scoring/criteria/update', this.form.value).subscribe(
      result => {
        if (result.status === 200) {
          this.toastrService.success('Changes saved successfully!', 'Saved Changes!');
          this.activeModal.close('success');
        } else {
          this.toastrService.error('Failed to update!', 'Failed!');
        }
      },
      error => {
        this.loading = false;
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }


  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }

  async getHighestBandValue() {
    const content = await this._httpService.scoresGet(`scoring/criteria/band/high/1`).toPromise();

    return content.data.nextFrom;

  }
}
