import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import {NavigationExtras, Router} from '@angular/router';
import { AddQualificationCriteriaComponent } from '../add-qualification-criteria/add-qualification-criteria.component';
import {QualificationCriteriaToQualificationParamsService} from '../../qualification-criteria-to-qualification-params.service';


@Component({
  selector: 'app-list-loan-products',
  templateUrl: './list-qualification-criteria.component.html',
  styleUrls: ['./list-qualification-criteria.component.scss'],
  providers: [DatePipe]
})
export class ListQualificationCriteriaComponent implements OnInit {

  tempItems = [
    {
      id: 1,
      product_name: 'QUALIFICATION_PERCENT',
      interest_rate: 'Digital Loan Qualification Percent Threshold',
      penalty_rate: 25,
      processing_fee: 'Active',
    },
    {
      id: 2,
      product_name: 'ACCOUNT_AGE',
      interest_rate: 'Age of the Account at Faulu',
      penalty_rate: 6,
      processing_fee: 'Active',

    }
  ];

  public isLoaded = false;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
        // { name: 'viewrecord', title: '&nbsp; &nbsp; <i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;'},
        { name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil fa-lg" style="text-decoration: none"></i> &nbsp;' },
        { name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg" style="text-decoration: none"></i> &nbsp;' }

      ],
      position: 'right'
    },
    // delete: {
    //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
    //   confirmDelete: true
    // },
    noDataMessage: 'No data found',
    columns: {
      product_id: {
        title: '#',
        type: 'text',
        filter: false,
        valuePrepareFunction: (value, row, cell) => {
          return cell.row.index + 1;
        }
      },
      valueFrom: {
        title: 'Value From',
        type: 'string',
        filter: false
      },
      valueTo: {
        title: 'Value To',
        type: 'string',
        filter: false
      },
      rating: {
        title: 'Rating',
        type: 'string',
        filter: false
      },
      addedClass : {
        title: 'Pricing',
        type: 'string',
        filter: false,
        valuePrepareFunction: (value) => {
          if (value === 'A') {
            return `CB Base rate (x%)`;
          } else
          if (value === 'B') {
            return `CB Base rate + Margin of 1%`;
          } else
          if (value === 'C') {
            return `CB Base rate + Margin of 2%`;
          } else
          if (value === 'D') {
            return `CB Base rate + Margin of 3%`;
          } else
          if (value === 'E') {
            return `Not within acceptable threshold`;
          }
        }
      }
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
              public datePipe: DatePipe, public toastrService: ToastrService, public router: Router,
              public qualificationCriteriaToQualificationParamsService: QualificationCriteriaToQualificationParamsService ) { }
  ngOnInit() {
    this.loadData();
  }
  private loadData(): any {

    this._httpService.scoresGet('scoring/criteria/?matrixId=1').subscribe(
      result => {
        console.log(' here is the qualification criteria result set');
        console.log(result);



        // add a new column to the returned items to be used for showing cb message
        const tweakedData = result.data.map((item) => {
          item.addedClass = item.rating;
          return item;
        });

        this.dataSet =  tweakedData;
      },
      error => {
      },
      complete => {
        this.isLoaded = true;
      }
    );
  }
  public openModal(parentData: any, editing: boolean) {
     this.modalRef = this.modalService.open(AddQualificationCriteriaComponent);
     this.modalRef.componentInstance.title = editing ? 'Update Qualification Criteria' : 'Add Qualification Criteria';
     this.modalRef.componentInstance.formData = parentData;
     this.modalRef.componentInstance.editing = editing;

     this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }

  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('profile/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }


  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        this.viewQualificationParams(event.data);
        break;
      case 'editrecord':
        this.editRecord(event.data);
        break;
      case 'deleterecord':
        this.deleteLoanProduct(event.data);
        break;
    }
  }

  deleteLoanProduct(data) {
    console.log('deleted loan product.');
    console.log(data);
  }

  editRecord(data) {
    console.log('edited loan product.');
    console.log(data);
    this.openModal(data, true);
  }

  viewQualificationParams(data) {
    const navigationExtras: NavigationExtras = data;

    this.qualificationCriteriaToQualificationParamsService.updateApprovalMessage(navigationExtras);
    this.router.navigate(['configs', 'qualification-params']);
  }

}
