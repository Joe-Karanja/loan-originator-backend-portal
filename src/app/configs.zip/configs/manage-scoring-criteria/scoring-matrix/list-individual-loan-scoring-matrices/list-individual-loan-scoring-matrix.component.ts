import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router, NavigationExtras } from '@angular/router';
import {RiskToScoreGroupService} from '../../risk-to-score-group.service';
import {AddRiskGroupComponent} from '../../risk-group/add-risk-group/add-risk-group.component';

@Component({
    selector: 'app-list-scoring-matrices',
    templateUrl: './list-individual-loan-scoring-matrix.component.html',
    styleUrls: ['./list-individual-loan-scoring-matrix.component.scss'],
    providers: [DatePipe]
})
export class ListIndividualLoanScoringMatrixComponent implements OnInit {

    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                {name: 'viewrecord', title: '&nbsp; &nbsp;&nbsp; &nbsp;<i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;'},
                // {name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil text-secondary fa-lg"></i> &nbsp; &nbsp;'},
                // {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },
            paramCode: {
                title: 'Param Code',
                type: 'string',
                filter: false
            },
            paramName: {
                title: 'Param Name',
                type: 'string',
                filter: false
            },
            type: {
                title: 'Type',
                type: 'string',
                filter: false
            },
            weight: {
                title: 'Weight',
                type: 'number',
                filter: false
            }
        },
        pager: {
            display: true,
            perPage: 50
        }
    };
    dataSet: any;

    // tslint:disable-next-line:variable-name
    constructor(private _httpService: HttpService,
                private modalService: NgbModal,
                public datePipe: DatePipe,
                public toastrService: ToastrService,
                public router: Router,
                private riskToScoreGroupService: RiskToScoreGroupService
    ) {
    }

    ngOnInit() {
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean) {
        this.modalRef = this.modalService.open(AddRiskGroupComponent);
        this.modalRef.componentInstance.title = editing ? 'Edit Scoring Risk' : 'Add Scoring Risk';
        this.modalRef.componentInstance.formData = parentData;

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {
            case 'viewrecord':
                this.viewScoringParams(event.data);
                break;
            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    viewScoringParams(data) {
        const navigationExtras: NavigationExtras = data;
        this.riskToScoreGroupService.updateApprovalMessage(navigationExtras);
        this.router.navigate(['configs', 'scoring-matrices' , 'risk-groups', 'scoring-groups', 'scoring-params', 'individual-scoring-params-items']);
    }

    private loadData(): any {

        this._httpService.scoresGet('scoring/risks').subscribe(
            result => {
                this.dataSet = [{
                    id: 1,
                    paramCode: 'P003',
                    paramName: 'Loan Purpose',
                    type: 'LIST',
                    weight: 125
                }, {
                    id: 2,
                    paramCode: 'P005',
                    paramName: 'Customer Sector',
                    type: 'LIST',
                    weight: 121
                }, {
                    id: 3,
                    paramCode: 'P006',
                    paramName: 'Customer Industry',
                    type: 'LIST',
                    weight: 151
                }, {
                    id: 4,
                    paramCode: 'P010',
                    paramName: 'Average Monthly bank turnover - 12 Months',
                    type: 'RANGE',
                    weight: 121
                }, {
                    id: 5,
                    paramCode: 'P013',
                    paramName: 'Delinquent loans - mobile',
                    type: 'RANGE',
                    weight: 121
                }, {
                    id: 6,
                    paramCode: 'P014',
                    paramName: 'Number of loans borrowed - Mobile',
                    type: 'RANGE',
                    weight: 138
                }, {
                    id: 7,
                    paramCode: 'P017',
                    paramName: 'Age of borrower',
                    type: 'RANGE',
                    weight: 136
                }, {
                    id: 8,
                    paramCode: 'P022',
                    paramName: 'Gender',
                    type: 'LIST',
                    weight: 121
                }, {
                    id: 9,
                    paramCode: 'P023',
                    paramName: 'Loan Amount Applied',
                    type: 'RANGE',
                    weight: 123
                }, {
                    id: 10,
                    paramCode: 'P025',
                    paramName: 'Non Digital Loans Tenure',
                    type: 'RANGE',
                    weight: 158
                }, {
                    id: 11,
                    paramCode: 'P026',
                    paramName: 'Days elapsed since last Mobile enquiry',
                    type: 'RANGE',
                    weight: 121
                }, {
                    id: 12,
                    paramCode: 'P027',
                    paramName: 'Total Mobile Enquiries',
                    type: 'RANGE',
                    weight: 162
                }, {
                    id: 13,
                    paramCode: 'P028',
                    paramName: 'Maximum defaulted days - non-mobile',
                    type: 'RANGE',
                    weight: 121
                }];

                    // result.data;
            },
            error => {
            },
            complete => {
                this.isLoaded = true;
            }
        );
    }

    private viewInsuranceProduct(data: any): void {
        this.router.navigate(['configs/investment-products', data.product_id]);
    }

}
