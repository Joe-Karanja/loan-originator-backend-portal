import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';
// import {AddRiskGroupComponent} from '../../risk-group/add-risk-group/add-risk-group.component';
// import {AddScoringParamItemComponent} from '../add-scoring-param-item/add-scoring-param-item.component';
// import {ScoreParameterToScoreParameterItemService} from '../../score-parameter-to-score-parameter-item.service';


@Component({
    selector: 'app-list-loan-products',
    templateUrl: './list-individual-scoring-param-item.component.html',
    styleUrls: ['./list-individual-scoring-param-item.component.scss'],
    providers: [DatePipe]
})
export class ListIndividualScoringParamItemComponent implements OnInit {

    public testData = [
        {
            id: 1,
            code: 'P006',
            description: 'Wholesale and retail',
            weight: '120.000',
            pointsToDouble: '20',
            referenceScore: '100',
            valueIncrementPortion: '28.900',
            offset: '487',
            unscaledWeight: '-0.03',
            intercept: '24.89'
        },
        {
            id: 2,
            code: 'P006',
            description: 'Crop farming',
            weight: '120.000',
            pointsToDouble: '20',
            referenceScore: '100',
            valueIncrementPortion: '28.900',
            offset: '487',
            unscaledWeight: '-0.03',
            intercept: '24.89'
        },
        {
            id: 3,
            code: 'P006',
            description: 'Livestock',
            weight: '151.000',
            pointsToDouble: '20',
            referenceScore: '100',
            valueIncrementPortion: '28.900',
            offset: '487',
            unscaledWeight: '1.05',
            intercept: '24.89'
        },
        {
            id: 4,
            code: 'P006',
            description: 'Transport and Infrastructure',
            weight: '134.000',
            pointsToDouble: '20',
            referenceScore: '100',
            valueIncrementPortion: '28.900',
            offset: '487',
            unscaledWeight: '0.46',
            intercept: '24.89'
        },
        {
            id: 5,
            code: 'P006',
            description: 'Others',
            weight: '121.000',
            pointsToDouble: '20',
            referenceScore: '100',
            valueIncrementPortion: '28.900',
            offset: '487',
            unscaledWeight: '0',
            intercept: '24.89'
        }
    ];

    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                // { name: 'viewrecord', title: '&nbsp; &nbsp; <i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;' },
                { name: 'editrecord', title: '<i class="fa fa-pencil text-secondary fa-lg"></i> &nbsp; &nbsp;' },
                {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            product_id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },

            code: {
                title: 'Code',
                type: 'string',
                filter: false,
            },

            description: {
                title: 'Description',
                type: 'string',
                filter: false,
            },

            weight: {
                title: 'Weight',
                type: 'string',
                filter: false,
            },

            pointsToDouble: {
                title: 'PointsToDouble',
                type: 'string',
                filter: false,
            },

            referenceScore: {
                title: 'ReferenceScore',
                type: 'string',
                filter: false,
            },

            valueIncrementPortion: {
                title: 'ValueIncrementPortion',
                type: 'string',
                filter: false,
            },

            offset: {
                title: 'Offset',
                type: 'string',
                filter: false,
            },

            unscaledWeight: {
                title: 'UnscaledWeight',
                type: 'string',
                filter: false,
            },

            intercept: {
                title: 'Intercept',
                type: 'string',
                filter: false,
            },

        },
        pager: {
            display: true,
            perPage: 15
        }
    };
    dataSet: any;
    message: any;

    constructor(private _httpService: HttpService,
                private modalService: NgbModal,
                public datePipe: DatePipe,
                public toastrService: ToastrService,
                public router: Router,
                // private scoreParameterToScoreParameterItemService: ScoreParameterToScoreParameterItemService
    ) {
    }

    ngOnInit() {
        // this.scoreParameterToScoreParameterItemService.currentScoreParamsData.subscribe(msg => this.message = msg);
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean) {
        // this.modalRef = this.modalService.open(AddScoringParamItemComponent);
        this.modalRef.componentInstance.title = editing ? 'Edit Scoring Parameter Item' : 'Add Scoring Parameter Item';
        this.modalRef.componentInstance.editing = editing;
        this.modalRef.componentInstance.isRange = this.message.type;
        this.modalRef.componentInstance.groupId = this.message.id;
        this.modalRef.componentInstance.riskName = this.message.name;

        this.modalRef.componentInstance.formData = parentData;

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {
            case 'viewrecord':
                this.viewScoringParams(event.data);
                break;
            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    viewScoringParams(data) {
        console.log('edited loan product.');
        console.log(data);
        this.router.navigate(['/']);
    }

    private loadData(): any {

        console.log('this.message');
        console.log(this.message);

        this._httpService.scoresGet(`scoring/parameters/item?id=${1}&size=50&page=0`).subscribe(
            result => {
                this.dataSet = this.testData;
                    // result.data;
            },
            error => {
            },
            complete => {
                this.isLoaded = true;
            }
        );
    }

    private viewInsuranceProduct(data: any): void {
        this.router.navigate(['configs/investment-products', data.product_id]);
    }

}
