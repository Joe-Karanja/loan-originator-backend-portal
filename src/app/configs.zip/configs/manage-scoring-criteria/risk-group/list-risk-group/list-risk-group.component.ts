import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router, NavigationExtras } from '@angular/router';
import {AddRiskGroupComponent} from '../add-risk-group/add-risk-group.component';
import {RiskToScoreGroupService} from '../../risk-to-score-group.service';
import { MatrixToRiskGroupService } from '../../matrix-to-risk-group.service';

@Component({
    selector: 'app-list-loan-products',
    templateUrl: './list-risk-group.component.html',
    styleUrls: ['./list-risk-group.component.scss'],
    providers: [DatePipe]
})
export class ListRiskGroupComponent implements OnInit {

    public testData = [{
        id: 1,
        product_name: 'P001',
        interest_rate: 'Financial',
        penalty_rate: 'RANGE',
        processing_fee: '120',
    },
        {
            id: 2,
            product_name: 'P002',
            interest_rate: 'Collateral',
            penalty_rate: 'LIST',
            processing_fee: '120',

        }];

    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                {name: 'viewrecord', title: '&nbsp; &nbsp;&nbsp; &nbsp;<i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;'},
                {name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil text-secondary fa-lg"></i> &nbsp; &nbsp;'},
                {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },
            name: {
                title: 'Risk Name',
                type: 'string'
            },
            maxScore: {
                title: 'Weight',
                type: 'number'
            },
            enabled: {
                title: 'Status',
                type: 'html',
                valuePrepareFunction: (value) => {
                    let formatted;
                    if (value) {
                        formatted = '<span class="badge badge-success">Active</span>';
                    } else {
                        formatted = '<span class="badge badge-danger">Inactive</span>';
                    }
                    return formatted;
                },
            }
        },
        pager: {
            display: true,
            perPage: 5
        }
    };
    dataSet: any;

    message: any;

    matrixId: number;

    // tslint:disable-next-line:variable-name
    constructor(private _httpService: HttpService,
                private modalService: NgbModal,
                public datePipe: DatePipe,
                public toastrService: ToastrService,
                public router: Router,
                private riskToScoreGroupService: RiskToScoreGroupService,
                private matrixToRiskGroupService: MatrixToRiskGroupService,
    ) {
    }

    ngOnInit() {

        this.matrixToRiskGroupService.currentMatrixData.subscribe(msg => {
            this.message = msg;

            this.loadData();

        });
    }

    public openModal(parentData: any, editing: boolean) {
        this.modalRef = this.modalService.open(AddRiskGroupComponent);
        this.modalRef.componentInstance.title = editing ? 'Edit Scoring Risk' : 'Add Scoring Risk';
        this.modalRef.componentInstance.formData = parentData;
        this.modalRef.componentInstance.matrixId = this.message.id;

        console.log('***************this.matrix.message**************');
        console.log(this.message);

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {
            case 'viewrecord':
                this.viewScoringParams(event.data);
                break;
            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    viewScoringParams(data) {

        data.title = this.message.name;
        data.prevUrl = this.router.url;



        const navigationExtras: NavigationExtras = data;
        this.riskToScoreGroupService.updateApprovalMessage(navigationExtras);
        // @ts-ignore

        console.log('here are the navigationExtras');
        console.log(navigationExtras);
        console.log(navigationExtras);

        this.router.navigate(['configs', 'scoring-matrices' , 'risk-groups', 'scoring-groups']);

    }

    private loadData(): any {
            this._httpService.scoresGet(`scoring/risks?scoringMatrixId=${this.message.id}`).subscribe(
                result => {
                    this.dataSet = result.data;
                },
                error => {
                    this.dataSet = this.testData;
                },
                complete => {
                    this.isLoaded = true;
                }
            );
    }

}
