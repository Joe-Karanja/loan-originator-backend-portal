import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-loan-product',
  templateUrl: './add-risk-group.component.html',
  styleUrls: ['./add-risk-group.component.scss']
})
export class AddRiskGroupComponent implements OnInit {

  @Input() title;
  @Input() formData;
  @Input() matrixId;

  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;

  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }

  ngOnInit() {
    this.form = this.fb.group({
      name: [this.formData ? this.formData.name : '', [Validators.required]],
    });

  }

  public submitData(): void {

    if (this.formData) {
     // do edits
     this.saveChanges();
    } else {
      // create new
      this.createRecord();
    }
    this.loading = true;
  }
  private createRecord(): any {
    const newModel = {...this.form.value};

    newModel.scoringMatrixId = this.matrixId;

    this._httpService.scoresPost('scoring/create/risk', newModel).subscribe(
      result => {
       if (result.status === 200) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.toastrService.error('Failed to create!', 'Failed!');
        }
      },
      error => {
      },
      complete => {
        this.loading = false;
      }

    );
  }
  private saveChanges(): any {
    this._httpService.scoresPost('scoring/risk/update', {
      id: 2,
      enabled: false
    }
    ).subscribe(
      result => {
        // if (result.response.response_code === this._httpService.errCodes.SUCCES_CODE) {
          this.toastrService.success('Changes saved successfully!', 'Saved Changes!');
          this.activeModal.close('success');
        // } else {
        //   this._httpService.handleErrorsFromServer(result.errors);
        // }
      },
      error => {
        this.loading = false;
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }


  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }

}
