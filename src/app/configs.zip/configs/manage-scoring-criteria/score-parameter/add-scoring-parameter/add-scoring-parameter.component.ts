import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-loan-product',
  templateUrl: './add-scoring-parameter.component.html',
  styleUrls: ['./add-scoring-parameter.component.scss']
})
export class AddScoringParameterComponent implements OnInit {

  @Input() title;
  @Input() formData;
  @Input() editing;
  @Input() groupId;
  @Input() riskName;


  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;
  options = [{id: 'RANGE'}, {id: 'LIST'}];

  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }
  ngOnInit() {
    this.form = this.fb.group({
      name: [this.formData ? this.formData.name : '', [Validators.required]],
      type: [this.formData ? this.formData.type : this.options[0].id],
      groupId: [this.groupId],
    });
    if (this.formData) {
    }
  }

  public submitData(): void {

    if (this.formData) {
     this.saveChanges();
    } else {
      this.createRecord();
    }
    this.loading = true;
  }
  private createRecord(): any {

    this._httpService.scoresPost('scoring/create/parameter', this.form.value).subscribe(
      result => {
       if (result.status === 200) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.toastrService.error('Failed to create!', 'Failed!');
        }
      },
      error => {
      },
      complete => {
        this.loading = false;
      }

    );
  }
  private saveChanges(): any {
    this._httpService.scoresPost('scoring/parameters/update', {
      id: this.form.value.id,
      weight: this.form.value.weight,
      enabled: true
    }).subscribe(
      result => {
        if (result.status === 200) {
          this.toastrService.success('Changes saved successfully!', 'Saved Changes!');
          this.activeModal.close('success');
        } else {
          this._httpService.handleErrorsFromServer(result.errors);
        }
      },
      error => {
        this.loading = false;
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }


  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }

}
