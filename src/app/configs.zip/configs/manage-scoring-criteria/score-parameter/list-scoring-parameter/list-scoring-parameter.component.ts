import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {NavigationExtras, Router} from '@angular/router';
import {AddRiskGroupComponent} from '../../risk-group/add-risk-group/add-risk-group.component';
import {AddScoringParameterComponent} from '../add-scoring-parameter/add-scoring-parameter.component';
import {ScoreGroupToScoreParameterService} from '../../score-group-to-score-parameter.service';
import {ScoreParameterToScoreParameterItemService} from '../../score-parameter-to-score-parameter-item.service';


@Component({
    selector: 'app-list-loan-products',
    templateUrl: './list-scoring-parameter.component.html',
    styleUrls: ['./list-scoring-parameter.component.scss'],
    providers: [DatePipe]
})
export class ListScoringParameterComponent implements OnInit {

    public testData = [
        {
            id: 1,
            product_name: 'P001',
            interest_rate: 'Current Ratio',
            penalty_rate: '20',
        },
        {
            id: 2,
            product_name: 'P001',
            interest_rate: 'Quick Ratio',
            penalty_rate: '30',
        }
    ];

    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                { name: 'viewrecord', title: '&nbsp; &nbsp; <i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;' },
                { name: 'editrecord', title: '<i class="fa fa-pencil text-secondary fa-lg"></i> &nbsp; &nbsp;' },
                {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            product_id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },
            name: {
                title: 'Name',
                type: 'string'
            },
            type: {
                title: 'Type',
                type: 'string'
            },
            maxScore: {
                title: 'Weight',
                type: 'number'
            },
            enabled: {
                title: 'Status',
                type: 'html',
                valuePrepareFunction: (value) => {
                    let formatted;
                    if (value) {
                        formatted = '<span class="badge badge-success">Active</span>';
                    } else {
                        formatted = '<span class="badge badge-danger">Inactive</span>';
                    }
                    return formatted;
                },
            }
        },
        pager: {
            display: true,
            perPage: 5
        }
    };
    dataSet: any;
    message: any;


    constructor(private _httpService: HttpService, private modalService: NgbModal,
                public datePipe: DatePipe, public toastrService: ToastrService, public router: Router,
                private scoreGroupToScoreParameterService: ScoreGroupToScoreParameterService,
                private scoreParameterToScoreParameterItemService: ScoreParameterToScoreParameterItemService,
                ) {
    }

    ngOnInit() {
        this.scoreGroupToScoreParameterService.currentScoreGroupData.subscribe(msg => this.message = msg);
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean, groupId: number, riskName: string) {
        this.modalRef = this.modalService.open(AddScoringParameterComponent);
        this.modalRef.componentInstance.title = editing ? 'Edit Scoring Parameter' : 'Add Scoring Parameter';
        this.modalRef.componentInstance.editing = editing;
        this.modalRef.componentInstance.groupId = groupId;
        this.modalRef.componentInstance.riskName = riskName;

        this.modalRef.componentInstance.formData = parentData;

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {
            case 'viewrecord':
                this.viewScoringParams(event.data);
                break;
            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true, this.message.id, this.message.name);
    }

    viewScoringParams(data) {

        data.title = this.message.title;
        data.prevUrl = this.router.url;

        const navigationExtras: NavigationExtras = data;
        this.scoreParameterToScoreParameterItemService.updateApprovalMessage(navigationExtras);

        this.router.navigate(['configs', 'scoring-matrices', 'risk-groups', 'scoring-groups', 'scoring-params', 'scoring-params-items']);
    }

    private loadData(): any {

        console.log('this.message');
        console.log(this.message);
        this._httpService.scoresGet(`scoring/parameters?size=50&page=0&groupId=${this.message.id}`).subscribe(
            result => {
                this.dataSet = result.data;
            },
            error => {
            },
            complete => {
                this.isLoaded = true;
            }
        );
    }

    private viewInsuranceProduct(data: any): void {
        this.router.navigate(['configs/investment-products', data.product_id]);
    }

}
