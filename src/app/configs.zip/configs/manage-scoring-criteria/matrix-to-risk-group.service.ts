import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {NavigationExtras} from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class MatrixToRiskGroupService {

    private matrixData = new BehaviorSubject(null);
    currentMatrixData = this.matrixData.asObservable();

    constructor() {

    }

    updateApprovalMessage(message: NavigationExtras) {
        this.matrixData.next(message);
    }
}
