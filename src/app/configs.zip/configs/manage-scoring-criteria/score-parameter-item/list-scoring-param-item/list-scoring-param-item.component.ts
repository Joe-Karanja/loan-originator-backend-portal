import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';
import {AddRiskGroupComponent} from '../../risk-group/add-risk-group/add-risk-group.component';
import {AddScoringParamItemComponent} from '../add-scoring-param-item/add-scoring-param-item.component';
import {ScoreParameterToScoreParameterItemService} from '../../score-parameter-to-score-parameter-item.service';


@Component({
    selector: 'app-list-loan-products',
    templateUrl: './list-scoring-param-item.component.html',
    styleUrls: ['./list-scoring-param-item.component.scss'],
    providers: [DatePipe]
})
export class ListScoringParamItemComponent implements OnInit {

    public testData = [
        {
            id: 1,
            valueTo: '5',
            valueFrom: '0',
            name: null,
            weight: 3,
            enabled: true,
            createdDate: '2022-06-35 09:35:26'
        },
        {
            id: 2,
            valueTo: '10',
            valueFrom: '5',
            name: null,
            weight: 3,
            enabled: true,
            createdDate: '2022-06-35 09:35:26'
        }
    ];

    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                // { name: 'viewrecord', title: '&nbsp; &nbsp; <i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;' },
                { name: 'editrecord', title: '<i class="fa fa-pencil text-secondary fa-lg"></i> &nbsp; &nbsp;' },
                {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            product_id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },
            valueFrom: {
                title: 'Value From',
                type: 'string',
                valuePrepareFunction: (value) => {
                    if (value === 0 || value > 0) {
                        return value;
                    } else {
                        return 'N/A';
                    }
                },
            },
            valueTo: {
                title: 'Value To',
                type: 'string',
                valuePrepareFunction: (value) => {
                    if (value === 0 || value > 0) {
                        return value;
                    } else {
                        return 'N/A';
                    }
                },
            },
            name: {
                title: 'Parameter Item Name',
                type: 'string',
                valuePrepareFunction: (value) => {
                    if (value) {
                        return value;
                    } else {
                        return 'N/A';
                    }
                },
            },
            weight: {
                title: 'Weight',
                type: 'string'
            },
            enabled: {
                title: 'Status',
                type: 'html',
                valuePrepareFunction: (value) => {
                    let formatted;
                    if (value) {
                        formatted = '<span class="badge badge-success">Active</span>';
                    } else {
                        formatted = '<span class="badge badge-danger">Inactive</span>';
                    }
                    return formatted;
                },
            },
        },
        pager: {
            display: true,
            perPage: 30
        }
    };
    dataSet: any;
    message: any;

    constructor(private _httpService: HttpService, private modalService: NgbModal,
                public datePipe: DatePipe, public toastrService: ToastrService, public router: Router,
                private scoreParameterToScoreParameterItemService: ScoreParameterToScoreParameterItemService) {
    }

    ngOnInit() {
        this.scoreParameterToScoreParameterItemService.currentScoreParamsData.subscribe(msg => this.message = msg);
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean) {
        this.modalRef = this.modalService.open(AddScoringParamItemComponent);
        this.modalRef.componentInstance.title = editing ? 'Edit Scoring Parameter Item' : 'Add Scoring Parameter Item';
        this.modalRef.componentInstance.editing = editing;
        this.modalRef.componentInstance.isRange = this.message.type;
        this.modalRef.componentInstance.groupId = this.message.id;
        this.modalRef.componentInstance.riskName = this.message.name;

        this.modalRef.componentInstance.formData = parentData;

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {
            case 'viewrecord':
                this.viewScoringParams(event.data);
                break;
            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    viewScoringParams(data) {
        console.log('edited loan product.');
        console.log(data);
        this.router.navigate(['/']);
    }

    private loadData(): any {

        console.log('this.message');
        console.log(this.message);

        this._httpService.scoresGet(`scoring/parameters/item?id=${this.message.id}&size=50&page=0`).subscribe(
            result => {
                this.dataSet = result.data;
            },
            error => {
            },
            complete => {
                this.isLoaded = true;
            }
        );
    }

    private viewInsuranceProduct(data: any): void {
        this.router.navigate(['configs/investment-products', data.product_id]);
    }

}
