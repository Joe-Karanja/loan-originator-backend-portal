import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {NavigationExtras} from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class ScoreParameterToScoreParameterItemService {

    private scoreParamsData = new BehaviorSubject(null);
    currentScoreParamsData = this.scoreParamsData.asObservable();

    constructor() {

    }

    updateApprovalMessage(message: NavigationExtras) {
        this.scoreParamsData.next(message);
    }
}
