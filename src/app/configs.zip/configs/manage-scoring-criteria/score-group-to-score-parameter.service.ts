import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {NavigationExtras} from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class ScoreGroupToScoreParameterService {

    private scoreGroupData = new BehaviorSubject(null);
    currentScoreGroupData = this.scoreGroupData.asObservable();

    constructor() {

    }

    updateApprovalMessage(message: NavigationExtras) {
        this.scoreGroupData.next(message);
    }
}
