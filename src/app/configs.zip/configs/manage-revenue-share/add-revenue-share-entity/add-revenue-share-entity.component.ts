import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-scoring-matrix',
  templateUrl: './add-revenue-share-entity.component.html',
  styleUrls: ['./add-revenue-share-entity.component.scss']
})
export class AddRevenueShareEntityComponent implements OnInit {

  @Input() title;
  @Input() formData;
  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;

  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }

  ngOnInit() {
    this.form = this.fb.group({
      name: [this.formData ? this.formData.name : '', [Validators.required]],
      cbRate: [this.formData ? this.formData.cbRate : '', [Validators.required]],
      enabled: [true],
      id: [1],
    });

  }

  public submitData(): void {

    if (this.formData) {
     // do edits
     this.saveChanges();
    } else {
      // create new
      this.createRecord();
    }
    this.loading = true;
  }
  private createRecord(): any {

    this._httpService.scoresPost('scoring/create/matrix', this.form.value).subscribe(
      result => {
       if (result.status === 200) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.toastrService.error('Failed to create!', 'Failed!');
        }
      },
      error => {
      },
      complete => {
        this.loading = false;
      }

    );
  }
  private saveChanges(): any {
    this._httpService.scoresPost('scoring/update/matrix', this.form.value
    ).subscribe(
      result => {
        if (result.status === 200) {
          this.toastrService.success('Changes saved successfully!', 'Saved Changes!');
          this.activeModal.close('success');
        } else {
          this._httpService.handleErrorsFromServer(result.errors);
        }
      },
      error => {
        this.loading = false;
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }


  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }

}
