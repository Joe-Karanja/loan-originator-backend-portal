import {DatePipe} from '@angular/common';
import {HttpService} from 'src/app/shared/services/http.service';
import {Component, OnInit} from '@angular/core';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router, NavigationExtras } from '@angular/router';
import {AddRevenueShareEntityComponent} from '../add-revenue-share-entity/add-revenue-share-entity.component';

@Component({
    selector: 'app-list-scoring-matrices',
    templateUrl: './list-revenue-share-entities.component.html',
    styleUrls: ['./list-revenue-share-entities.component.scss'],
    providers: [DatePipe]
})
export class ListRevenueShareEntitiesComponent implements OnInit {

    public testData = [{
        id: 1,
        name: 'Eclectics International',
        enabled: true,
        maxScore: '30%'
    }];

    public isLoaded = false;
    public formData;
    public modalRef: NgbModalRef;
    public settings = {
        selectMode: 'single',  // single|multi
        hideHeader: false,
        hideSubHeader: false,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            custom: [
                {name: 'viewrecord', title: '&nbsp; &nbsp;&nbsp; &nbsp;<i class="fa fa-list fa-lg"></i>  &nbsp; &nbsp;'},
                {name: 'editrecord', title: '&nbsp; <i class="fa fa-pencil text-secondary fa-lg"></i> &nbsp; &nbsp;'},
                {name: 'deleterecord', title: '&nbsp; <i class="fa fa-trash-o text-danger fa-lg"></i> &nbsp;'}

            ],
            position: 'right'
        },
        // delete: {
        //   deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
        //   confirmDelete: true
        // },
        noDataMessage: 'No data found',
        columns: {
            id: {
                title: '#',
                type: 'text',
                filter: false,
                valuePrepareFunction: (value, row, cell) => {
                    return cell.row.index + 1;
                }
            },
            name: {
                title: 'Revenue Share Entity Name',
                type: 'string',
                filter: false
            },
            maxScore: {
                title: 'Percentage',
                type: 'string',
                filter: false
            },
            enabled: {
                title: 'Entity Status',
                type: 'html',
                filter: false,
                valuePrepareFunction: (value) => {
                    let formatted;
                    if (value) {
                        formatted = '<span class="badge badge-success" style="text-align: center;">Active</span>';
                    } else {
                        formatted = '<span class="badge badge-danger" style="text-align: center;">Inactive</span>';
                    }
                    return formatted;
                },
            }
        },
        pager: {
            display: true,
            perPage: 5
        }
    };
    dataSet: any;

    // tslint:disable-next-line:variable-name
    constructor(private _httpService: HttpService,
                private modalService: NgbModal,
                public datePipe: DatePipe,
                public toastrService: ToastrService,
                public router: Router,
    ) {
    }

    ngOnInit() {
        this.loadData();
    }

    public openModal(parentData: any, editing: boolean) {
        this.modalRef = this.modalService.open(AddRevenueShareEntityComponent);
        this.modalRef.componentInstance.title = editing ? 'Edit Revenue Share Entity' : 'Add Revenue Share Entity';
        this.modalRef.componentInstance.formData = parentData;


        console.log('Scoring matrix data');
        console.log(this.dataSet);

        this.modalRef.result.then((result) => {
            if (result === 'success') {
                this.loadData();
            }
        }, (reason) => {
        });
    }

    public onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this._httpService.delete('profile/' + event.data.id).subscribe(
                result => {
                    if (result.response_code === 200) {
                        event.confirm.resolve();
                        this.toastrService.success(event.data.id, 'Deleted!');
                    } else {
                        this.toastrService.error(event.data.id, 'Failed to Delete!');
                    }
                }
            );
        } else {
            event.confirm.reject();
        }
    }

    onCustomAction(event) {
        switch (event.action) {
            case 'viewrecord':
                this.viewScoringMatrix(event.data);
                break;
            case 'editrecord':
                this.editRecord(event.data);
                break;
            case 'deleterecord':
                this.deleteLoanProduct(event.data);
                break;
        }
    }

    deleteLoanProduct(data) {
        console.log('deleted loan product.');
        console.log(data);
    }

    editRecord(data) {
        console.log('edited loan product.');
        console.log(data);
        this.openModal(data, true);
    }

    viewScoringMatrix(data) {

        const navigationExtras: NavigationExtras = data;

        if (data.id === 1) {
            this.router.navigate(['configs', 'scoring-matrices', 'risk-groups']);
        } else if (data.id === 2) {
            this.router.navigate(['configs', 'scoring-matrices', 'risk-groups']);
            // this.router.navigate(['configs', 'scoring-matrices', 'individual-loan']);
        }
    }

    private loadData(): any {
        this._httpService.scoresGet('scoring/matrices').subscribe(
            result => {
                this.dataSet =  this.testData;
                    // result.data;
            }
        );
    }
}
