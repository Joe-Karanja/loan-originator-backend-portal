import { ViewProfileComponent } from './../view-profile/view-profile.component';
import { AddProfileComponent } from './../add-profile/add-profile.component';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AssignUserToProfileComponent } from './../view-profile/assign-user-to-profile/assign-user-to-profile.component';

@Component({
  selector: 'app-list-profiles',
  templateUrl: './list-profiles.component.html',
  styleUrls: ['./list-profiles.component.scss'],
  providers: [DatePipe]
})
export class ListProfilesComponent implements OnInit {
  @Input() data;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
      //  { name: 'viewrecord', title: '<i class="fa fa-eye text-center mr-2"></i>View ' },
      //  { name: 'editrecord', title: '&nbsp;&nbsp;<i class="fa  fa-pencil"></i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      id: {
        title: '#',
        type: 'string',
        filter: false,
        valuePrepareFunction: (value, row, cell) => {
          return cell.row.index + 1;
        }
      },
      profile_name: {
        title: 'Profile',
        type: 'string'
      },
      description: {
        title: 'Description',
        type: 'string'
      }
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe, public toastrService: ToastrService) { }
  ngOnInit() {
    this.loadData();
  }
  private loadData(): any {
    this.dataSet = [
      {profile_name: 'Super Admin', description: 'Super User Account'},
      {profile_name: 'Loans Approver', description: 'Approves all loans'},
      {profile_name: 'Verifier', description: 'Checks for necessary documents'},
    ]
    // this._httpService.get('rbac/profile').subscribe(
    //   result => {
    //     if (result.response.code === this._httpService.errCodes.SUCCESS_CODE) {
    //       this.dataSet = result.data;
    //     } else {
    //     }
    //   },
    //   error => {
    //   },
    //   complete => {
    //   }
    // );
  }
  public openModal(parentData: any) {
    this.modalRef = this.modalService.open(AddProfileComponent);
    this.modalRef.componentInstance.title = 'Add Profile';
    this.modalRef.componentInstance.parentData = '';
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public editRecord(formData: any) {
    this.modalRef = this.modalService.open(AddProfileComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.componentInstance.title = 'Edit Profile: ';
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('profile/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }
  public viewRecord(formData: any) {
    this.modalRef = this.modalService.open(ViewProfileComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
      }
    }, (reason) => {
    });
  }

  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        this.viewRecord(event.data);
        break;
      case 'editrecord':
        this.editRecord(event.data);
    }
  }

}
