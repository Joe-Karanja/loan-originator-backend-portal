import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AssignUserToProfileComponent } from './assign-user-to-profile/assign-user-to-profile.component';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss'],
  providers: [DatePipe]
})
export class ViewProfileComponent implements OnInit {
  @Input() formData;
  details: any;
  @Input() data;
  public modalRef: NgbModalRef;
  public dataSet;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
        { name: 'deleteRecord', title: '<i class="fa fa-trash">&nbsp;Remove</i>' },
        ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      username: {
        title: 'Username',
        type: 'string'
      },
      email_address: {
        title: 'Email Address',
        type: 'string'
      },
      created_on: {
        title: 'Created On',
        type: 'string',
        valuePrepareFunction: (date) => {
          const raw = new Date(date);
          const formatted = this.datePipe.transform(raw, 'dd MMM yyyy');
          return formatted;
        },
      },
    },
    pager: {
      display: true,
      perPage: 50
    }
  };
  constructor( public activeModal: NgbActiveModal, private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe, public toastrService: ToastrService) { }

  ngOnInit() {
    this.details = this.formData;
    this.loadData();
  }
  private loadData(): any {
    this._httpService.get('user/profile/' + this.formData.id + '/users').subscribe(
      result => {
        if (result.response.response_code === this._httpService.errCodes.SUCCESS_CODE) {
          this.dataSet = result.data;
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }
  public openModal() {
    this.modalRef = this.modalService.open(AssignUserToProfileComponent);
    this.modalRef.componentInstance.title = 'Add user to ' + this.formData.profile_name;
    this.modalRef.componentInstance.parentData = this.formData;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }

  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to remove the user from profile?')) {
      this._httpService.delete('user/profile/' + this.formData.id + '/assign/' + event.data.id).subscribe(
        result => {
          if (result.response.response_code === this._httpService.errCodes.SUCCESS_CODE) {
            this.toastrService.success(event.data.id, 'Deleted!');
            this.loadData();
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }
  public onCustomAction(event: any): void {
    switch (event.action) {
      case 'deleteRecord':
        this.onDeleteConfirm(event);
        break;
      default:
        break;
    }
  }
}
