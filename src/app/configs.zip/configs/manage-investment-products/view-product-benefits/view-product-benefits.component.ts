import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from 'src/app/shared/services/http.service';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AddInvestmentBenefitComponent } from '../add-investment-benefit/add-investment-benefit.component';
// import { AddBenefitComponent } from '../add-benefit/add-benefit.component';

@Component({
  selector: 'app-view-product-benefits',
  templateUrl: './view-product-benefits.component.html',
  styleUrls: ['./view-product-benefits.component.scss']
})
export class ViewProductBenefitsComponent implements OnInit {
  @Input() title;
  @Input() category;
  isLoaded: boolean = false;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
        // { name: 'viewrecord', title: '<i class="fa fa-eye"> Benefits</i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      benefit_name: {
        title: 'Benefit Name',
        type: 'string'
      },
      benefit_description: {
        title: 'Benefit Description',
        type: 'string'
      },
      // limit_value: {
      //   title: 'Limit Value',
      //   type: 'string'
      // },
      // is_optional: {
      //   title: 'Is Optional',
      //   type: 'string'
      // }
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(
    public activeModal: NgbActiveModal,
    private _httpService: HttpService,
    public toastrService: ToastrService,
    private modalService: NgbModal,
  ) { }
  ngOnInit() {
    this.loadData();
  }
  public loadData(): void {
    this._httpService.model.entity = 'investment_benefit';
    this._httpService.model.where_clause = 'category_id';
    this._httpService.model.where_value = String(this.category.category_id);
    this._httpService.model.transaction_type = '10071';

    this._httpService.post('', this._httpService.model).subscribe(
      result => {
        this.dataSet = result.list;
      },
      error => {
      },
      complete => {
        this.isLoaded = true;
      }
    );

  }
  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }
  public addBenefit(parentData?: any) {
    this.modalRef = this.modalService.open(AddInvestmentBenefitComponent);
    this.modalRef.componentInstance.title = 'Add Benefit';
    this.modalRef.componentInstance.category_id = this.category.category_id;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }

  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        //    this.viewInsuranceProduct(event.data);
        break;
      case 'editrecord':
      //   this.editRecord(event.data);
    }
  }

}
