import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { AddInvestmentProductComponent } from '../add-investment-product/add-investment-product.component';
import { AddInvestmentCategoryComponent } from '../add-investment-category/add-investment-category.component';
import { ViewProductBenefitsComponent } from '../view-product-benefits/view-product-benefits.component';


@Component({
  selector: 'app-view-investment-product-categories',
  templateUrl: './view-investment-product-categories.component.html',
  styleUrls: ['./view-investment-product-categories.component.scss'],
  providers: [DatePipe]
})
export class ViewInvestmentProductCategoriesComponent implements OnInit {
  selectedCategory;
  public product_id;
  public isLoaded = false;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
        { name: 'viewrecord', title: '<i class="fa fa-eye">View Benefits</i>' },
        //  { name: 'editrecord', title: '&nbsp;&nbsp;<i class="fa  fa-pencil"></i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      category_name: {
        title: 'Category Name',
        type: 'string'
      },
      minimum_amount: {
        title: 'Minimum Amount',
        type: 'string'
      },
      minimum_topup: {
        title: 'Minimum Top Up',
        type: 'string'
      },

      investment_horizon: {
        title: 'Recommended',
        type: 'string'
      },
      risk_level: {
        title: 'Risk Level',
        type: 'string'
      },
      hurdle_rate: {
        title: 'Hurdle Rate',
        type: 'string'
      },
      management_fee: {
        title: 'Management Fee',
        type: 'string'
      },
      initial_fee: {
        title: 'Initial Fee',
        type: 'string'
      },
      duration: {
        title: 'Duration',
        type: 'string'
      }
    },
    pager: {
      display: true,
      perPage: 5
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal, private _activatedRoute: ActivatedRoute,
    public datePipe: DatePipe, public toastrService: ToastrService, public router: Router) { }
  ngOnInit() {
    this._activatedRoute.params.subscribe(params => {
      if (typeof params['id'] !== 'undefined') {
        this.product_id = params['id'];
        console.log(params['product_name']);
      }
    });
    this.loadData();
  }
  private loadData(): any {
    this._httpService.model.entity = 'investment_category';
    this._httpService.model.where_clause = 'product_id';
    this._httpService.model.where_value = this.product_id;
    this._httpService.model.transaction_type = '10071';

    this._httpService.post('', this._httpService.model).subscribe(
      result => {
        this.dataSet = result.list;
      },
      error => {
      },
      complete => {
        this.isLoaded = true;
      }
    );
  }
  public openModal(parentData: any) {
    this.modalRef = this.modalService.open(AddInvestmentCategoryComponent);
    this.modalRef.componentInstance.title = 'Add Investment Category';
    this.modalRef.componentInstance.product_id = Number(this.product_id);

    this.modalRef.componentInstance.parentData = '';
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public editRecord(formData: any) {
    // this.modalRef = this.modalService.open(CreateAssessmentComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.componentInstance.title = 'Edit User: ' + formData.username;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
      console.log('hete');
    });
  }
  public viewProductBenefits(formData: any) {
    this.modalRef = this.modalService.open(ViewProductBenefitsComponent);
    this.modalRef.componentInstance.category = formData;
    this.modalRef.componentInstance.title = 'View Benefits: ' + formData.category_name;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
      console.log('hete');
    });
  }
  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('profile/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }


  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        this.viewProductBenefits(event.data);
        break;
      case 'editrecord':
      //  this.editRecord(event.data);
    }
  }
  private viewInsuranceProduct(data: any): void {
    this.router.navigate(['configs/investment-products', data.product_id]);
  }


}
